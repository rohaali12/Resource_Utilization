<?php $__env->startSection('title'); ?>
AppER-Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">AppER</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><span>Store Details</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">

    <div class="row">
        <!-- BASIC INFO START -->
        <div class="col-12 mt-5">
            <div class="card m-2">
                <div class="card-title">
                    <div class="h4 m-4">Basic Information</div>
                </div>
                <div class="card-body">
                    <!-- /.details -->
                    <div class="row m-2">
                        <?php $__currentLoopData = $results_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between">
                                    <h6>STATUS</h6>
                                    <span class="badge badge-info font_size"><?php echo e($status); ?></span>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush ">
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Payment per month
                                            </div>
                                            <?php $__currentLoopData = $results_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="text-muted font_size">
                                                <?php echo e($package->price); ?>

                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Uninstalled At
                                            </div>
                                            <?php if($detail->app_uninstalled_date_time != NULL): ?>
                                            <div class="text-muted font_size">
                                                <?php echo e($detail->app_uninstalled_date_time); ?>

                                            </div>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <div class="h6">PAYMENT DETAILS</div>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                    <?php $__currentLoopData = $results_package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Package</div>
                                            <div class="text-muted font_size"><?php echo e($package->title); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Package Details</div>
                                            <div class="text-muted font_size"><?php echo e($package->package_detail); ?></div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.details -->
                </div>
            </div>
            <div class="card m-2">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6>DETAILS</h6>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Name</div>
                                            <div class="text-muted font_size"><?php echo e($detail->shop); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shopify Display Name</div>
                                            <div class="text-muted font_size"><?php echo e($detail->shop_owner); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shopify Plan Name</div>
                                            <div class="text-muted font_size"><?php echo e($detail->plan_name); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shope Owner</div>
                                            <div class="text-muted font_size"><?php echo e($detail->shop_owner); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Email</div>
                                            <div class="text-muted font_size"><?php echo e($detail->email); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">URL</div>
                                            <div class="text-muted font_size"><?php echo e($detail->shop_owner); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Domain</div>
                                            <div class="text-muted font_size"><?php echo e($detail->domain); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">UI</div>
                                            <?php if($detail->is_new_ui == 1): ?>
                                            <div class="text-muted font_size">
                                                New UI
                                            </div>
                                            <?php else: ?>
                                            <div class="text-muted font_size">
                                                Old UI
                                            </div>
                                            <?php endif; ?>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Currency</div>
                                            <div class="text-muted font_size"><?php echo e($detail->currency); ?></div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6>MODULES</h6>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Abandoned Cart
                                            </div>
                                            <?php if($detail->emails_paused_date_time === NULL): ?>
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            <?php else: ?>
                                            <span class="badge badge-success font_size">Active</span>
                                            <?php endif; ?>
                                        </li>

                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Order Follow up
                                            </div>
                                            <?php if($detail->followup_emails_paused_date_time === NULL): ?>
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            <?php else: ?>
                                            <span class="badge badge-success font_size">Active</span>
                                            <?php endif; ?>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- BASIC INFO END -->
            <!-- DETAIL INFO START -->
            <div class="card m-2">
                <div class="card-title">
                    <div class="h4 m-4">Details Information</div>
                </div>
                <div class="card-body">
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <div class="h6">REVENUE DETAILS</div>
                                </div>
                                <div class="card-body">
                                    <?php $__currentLoopData = $results_revenue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Click History</div>
                                            <div class="text-muted font_size"><?php echo e($revenue->clicks); ?></div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Total Revenue</div>
                                            <div class="text-muted font_size"><?php echo e($revenue->revenue); ?>

                                                <span class="small"><?php echo e($detail->currency); ?></span>
                                            </div>
                                        </li>
                                        <?php $__currentLoopData = $results_revenue30days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue30days): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Last 30 Days Revenue</div>
                                            <div class="text-muted font_size"> <?php echo e($revenue30days->revenue30days); ?>

                                                <span class="small"><?php echo e($detail->currency); ?></span>
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
            </div>
        </div>
        <!-- DETAIL INFO END -->
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable').length) {
    $('#dataTable').DataTable({});
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-project/resources/views/backend/pages/apper/details.blade.php ENDPATH**/ ?>