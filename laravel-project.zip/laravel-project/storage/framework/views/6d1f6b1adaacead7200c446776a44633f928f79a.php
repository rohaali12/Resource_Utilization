<?php if($errors->any()): ?>
    <div class="alert alert-danger" id="alert">
        <div class="text-center">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
    <div class="alert alert-success" id="alert">
        <div class="text-center">
            <p><?php echo e(Session::get('success')); ?></p>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <div class="alert alert-danger" id="alert">
        <div class="text-center">
            <p><?php echo e(Session::get('error')); ?></p>
        </div>
    </div>
<?php endif; ?>



<script>

var myDiv = document.getElementById('alert');

function hideDiv() {
        myDiv.style.display = 'none';
}

// Set a timeout to hide the div after 2 minutes (120 seconds)
setTimeout(hideDiv, 2000);


</script><?php /**PATH /var/www/html/laravel-project/resources/views/backend/layouts/partials/messages.blade.php ENDPATH**/ ?>