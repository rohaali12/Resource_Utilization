
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2018. All right reserved. Template by <a href="#">ADMIN</a>.</p>
    </div>
</footer>
<!-- footer area end--><?php /**PATH /var/www/html/laravel-project/resources/views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>