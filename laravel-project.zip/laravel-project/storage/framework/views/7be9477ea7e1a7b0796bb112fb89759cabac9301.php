<?php $__env->startSection('title'); ?>
White List IP - Admin Panel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">White List IP</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><span>All Data</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner my-5">
    <div class="d-flex justify-content-around">
        <!-- Salespop start -->
        <?php $__currentLoopData = $results_salespop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="m-5">
            <div class="card">
                <div class="card-header">
                    <div class="h4 float-left">Edit Salespop White Card IP</div>
                </div>
                <div class="card-body">
                    <div class="">
                        <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('admin.ipsalespop.update',$ip->id)); ?>" method="POST" name="salespop_form"
                            class="">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="inputIP_salespop" class="form-label">IP Address</label>
                                <input type="text" class="form-control" id="inputIP_salespop" name="inputIP_salespop"
                                    value="<?php echo e($ip->ip); ?>">
                            </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">Save changes</button>
                </div>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Salespop end -->
        <!-- Apper start -->
        <?php $__currentLoopData = $results_apper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="m-5">
            <div class="card">
                <div class="card-header">
                    <div class="h4 float-left">Edit Apper White Card IP</div>
                </div>
                <div class="card-body">
                    <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route('admin.ipapper.update',$ip->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="inputIP_apper" class="form-label">IP Address</label>
                            <input type="text" class="form-control" id="inputIP_apper" name="inputIP_apper"
                                value="<?php echo e($ip->ip); ?>">
                        </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">Save changes</button>
                </div>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Apper end -->
        <!-- Wheelify start -->
        <?php $__currentLoopData = $results_wheelify; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="m-5">
            <div class="card">
                <div class="card-header">
                    <div class="h4 float-left">Edit Wheelify White Card IP</div>
                </div>
                <div class="card-body">
                    <div class="">
                        <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('admin.ipwheelify.update',$ip->id)); ?>" method="POST" name="wheelify_form" class="">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label for="inputIP_wheelify" class="form-label">IP Address</label>
                                <input type="text" class="form-control" id="inputIP_wheelify" name="inputIP_wheelify"
                                    value="<?php echo e($ip->ip); ?>">

                            </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">Save changes</button>
                </div>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Wheelify end -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable1').length) {
    $('#dataTable1').DataTable({});
}
if ($('#dataTable2').length) {
    $('#dataTable2').DataTable({});
}
if ($('#dataTable3').length) {
    $('#dataTable3').DataTable({});
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-project/resources/views/backend/pages/whitecardIP/whitelist_edit.blade.php ENDPATH**/ ?>