<?php $__env->startSection('title'); ?>
wheelify-Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('admin-content'); ?>

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Wheelify</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                    <li><span>investigation</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            <?php echo $__env->make('backend.layouts.partials.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row m-3">
        <div class="col-12">
            <?php echo $__env->make('backend.layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- WEBHOOK START -->
        <div class="col-12">
            <div class="card m-2">
                <div class="card-body">
                    <!-- /.details -->
                    <div class="col-12 card">
                        <div class="card-title">
                            <div class="h4">Webhooks</div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('admin.wheelify.store')); ?>" name="call_webhooks"
                                class="d-flex">
                                <?php echo csrf_field(); ?>
                                <input type="text" id="url" name="url_webhooks" class="form-control"
                                    placeholder="Enter Your Store URL" />
                                <button type="submit" class="btn btn-primary">Check</button>
                            </form>
                            <?php if(!is_null($installed_webhooks) && count($installed_webhooks) > 0 ): ?>
                            <div class="list-group">
                                <div class="h6 text-center m-3 text-success">Installed webhooks are:</div>
                                <form method="POST" action="<?php echo e(route('admin.wheelify.store')); ?>" name="delete_webhooks">
                                    <?php echo csrf_field(); ?>
                                    <input class="form-control text-center" type="text" name="W_store"
                                        value="<?php echo e($results_details); ?>" readonly>
                                    <?php $__currentLoopData = $installed_webhooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_install): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                value="<?php echo e($item_install['id']); ?>" id="flexCheckDefault"
                                                name="webhooks[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                <?php echo e($item_install['topic']); ?>

                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#198754"
                                            class="bi bi-check-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                                        </svg>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="submit" class="btn btn-danger float-right m-1 show_confirm">Delete</button>
                                </form>
                                <?php endif; ?>
                                <?php if(!is_null($uninstalled_webhooks) && count($uninstalled_webhooks) > 0): ?>
                                <form method="POST" action="<?php echo e(route('admin.wheelify.store')); ?>" name="install_webhook">
                                    <?php echo csrf_field(); ?>
                                    <input class="form-control text-center" type="text" name="W_store"
                                        value="<?php echo e($results_details); ?>" readonly>
                                    <?php $__currentLoopData = $uninstalled_webhooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_uninstall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                value="<?php echo e($item_uninstall); ?>" id="flexCheckDefault"
                                                name="install_webhooks[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                <?php echo e($item_uninstall); ?>

                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#C82333"
                                            class="bi bi-x-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                        </svg>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="submit" class="btn btn-success float-right m-1">Install</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- /.details -->
                </div>
            </div>
        </div>
        <!-- WEBHOOK END -->
        <!-- JS START -->
        <div class="col-12">
            <div class="card m-2">
                <div class="card-body">
                    <!-- /.details -->
                    <div class="col-12 card">
                        <div class="card-title">
                            <div class="h4">JS</div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(route('admin.wheelify.store')); ?>" name="call_js" class="d-flex">
                                <?php echo csrf_field(); ?>
                                <input type="text" id="url" name="url_js" class="form-control"
                                    placeholder="Enter Your Store URL" />
                                <button type="submit" class="btn btn-primary">Check</button>
                            </form>
                            <?php if(!is_null($installed_script) && count($installed_script) > 0 ): ?>
                            <div class="list-group">
                                <div class="h6 text-center m-3 text-success">Installed JS is:</div>
                                <form method="POST" action="<?php echo e(route('admin.wheelify.store')); ?>" name="delete_js">
                                    <?php echo csrf_field(); ?>
                                    <input class="form-control text-center" type="text" name="js_store"
                                        value="<?php echo e($results_details); ?>" readonly>
                                    <?php $__currentLoopData = $installed_script; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $js): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="<?php echo e($js['id']); ?>"
                                                id="flexCheckDefault" name="js[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                <?php echo e($js['src']); ?>

                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#198754"
                                            class="bi bi-check-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                                        </svg>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="submit" class="btn btn-danger float-right m-1 show_confirm">Delete</button>
                                </form>
                                <?php endif; ?>
                                <?php if(!is_null($uninstalled_script) && count($uninstalled_script) > 0): ?>
                                <div class="h6 text-center m-3 text-success">Uninstalled JS is:</div>
                                <form method="POST" action="<?php echo e(route('admin.wheelify.store')); ?>" name="install_js"
                                    class="m-4">
                                    <?php echo csrf_field(); ?>
                                    <input class="form-control text-center my-1" type="text" name="js_store"
                                        value="<?php echo e($results_details); ?>" readonly>
                                    <?php $__currentLoopData = $uninstalled_script; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_uninstall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                value="<?php echo e($item_uninstall); ?>" id="flexCheckDefault" name="script[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                <?php echo e($item_uninstall); ?>

                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#C82333"
                                            class="bi bi-x-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                        </svg>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="h3 p-1 text-center">OR</div>
                                    <input type="text" id="url" name="script[]" class="form-control my-1"
                                        placeholder="Enter Script to be install:" />
                                    <button type="submit" class="btn btn-success m-1 float-right">Install</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- /.details -->
                </div>
            </div>
        </div>
        <!-- JS END -->
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable').length) {
    $('#dataTable').DataTable({});
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script type="text/javascript">
$('.show_confirm').click(function(event) {
    var form = $(this).closest("form");
    var name = $(this).data("name");
    event.preventDefault();
    swal({
            title: `Are you sure you want to delete?`,
            text: "Deleting will never be shown again.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            if (willDelete) {
                form.submit();
            }
        });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel-project/resources/views/backend/pages/wheelify/investigation.blade.php ENDPATH**/ ?>