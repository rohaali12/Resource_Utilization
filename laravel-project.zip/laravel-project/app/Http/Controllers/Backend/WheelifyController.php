<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class WheelifyController extends Controller
{
    
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }


    function index(){
        if (is_null($this->user) || !$this->user->can('wheelify.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $query = "SELECT `id` , `shop` , `email` , DATE_FORMAT(`app_reinstall_date_time` ,'%a, %e %M %Y %H:%i:%s') AS app_reinstall_date_time , DATE_FORMAT(`app_uninstalled_date_time` ,'%a, %e %M %Y %H:%i:%s') AS app_uninstalled_date_time FROM stores";
        $results = DB::connection('mysql4')->select($query);
        
        $wheelify = Admin::all();
        return view('backend.pages.wheelify.index', ['results' => $results], compact('wheelify'));
    }


// show store details
function show($id){

    if (is_null($this->user) || !$this->user->can('wheelify.view')) {
        abort(403, 'Sorry !! You are Unauthorized to view any admin !');
    }

    $store_details = "SELECT * FROM stores WHERE id = $id";
    $modules_details = "SELECT campaigns.campaign_name ,spin_a_sale_settings.is_active FROM campaigns JOIN spin_a_sale_settings ON spin_a_sale_settings.campaign_id = campaigns.id WHERE spin_a_sale_settings.store_id = $id";
    $revenue_details =  "SELECT Count(*) As clicks , SUM(revenue) As revenue FROM `campaign_analytics`  WHERE `store_id` = $id";
    $revenue30days = "SELECT SUM(revenue) As revenue30days   FROM campaign_analytics WHERE store_id = $id AND created_at BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()";
    $package = "SELECT packages.title,packages.package_detail,packages.price FROM packages JOIN stores ON stores.package_id = packages.id WHERE stores.id = $id";

    $results =  DB::connection('mysql4')->select($store_details);
    $results_modules =  DB::connection('mysql4')->select($modules_details);
    $results_revenue =  DB::connection('mysql4')->select($revenue_details);
    $results_revenue30days =  DB::connection('mysql4')->select($revenue30days);
    $results_package =   DB::connection('mysql4')->select($package);

    foreach($results as $store){
        $url = $store->shop;
        $token = $store->access_token;
    }
    try{   
        $config = array(
            'ShopUrl' => $url,
            'AccessToken' => $token,
        );
        $shopify = new \PHPShopify\ShopifySDK($config);
        $webhooks = $shopify->Webhook->get();

        $status = "active";
    }
    catch (\Exception $e){
        $status = "unrecognized login or wrong password";
    }

        $wheelify = Admin::all();
        return view('backend.pages.wheelify.details', ['results' => $results,'status' => $status, 'results_modules' => $results_modules , 'results_revenue' =>  $results_revenue , 'results_revenue30days' => $results_revenue30days , 'results_package' => $results_package], compact('wheelify'));
    
}

// investigation
function create()
{
    if (is_null($this->user) || !$this->user->can('wheelify.investigation')) {
        abort(403, 'Sorry !! You are Unauthorized to view any admin !');
    }
    $installed_webhooks = $uninstalled_webhooks = $installed_script = $uninstalled_script = [];
    $results_details = NULL;
    $wheelify = Admin::all();
    return view('backend.pages.wheelify.investigation', ['results_details' => $results_details , 'installed_webhooks' => $installed_webhooks , 'uninstalled_webhooks' => $uninstalled_webhooks , 'installed_script' => $installed_script, 'uninstalled_script' => $uninstalled_script], compact('wheelify'));
}
function store(Request $request)
{ 

    $W_url = $request->input('url_webhooks');
    $W_del = $request->input('webhooks');
    $store = $request->input('W_store');
    $install_webhooks = $request->input('install_webhooks');

    $S_js = $request->input('url_js');
    $js_del = $request->input('js');
    $js_store = $request->input('js_store');
    $js_script = $request->input('script');
    // dd($js_script);
        function store($url)
        {
            $store_details = "SELECT `access_token` , `shop` FROM stores WHERE `shop` ='".$url."' OR `domain` = '".$url."'";
            $results_details =  DB::connection('mysql4')->select($store_details);

            if($results_details)
            {
                foreach($results_details as $token){
                    $access_token = $token->access_token;
                }

                $config = array(
                    'ShopUrl' => $url,
                    'AccessToken' => $access_token,
                );
                    $shopify = new \PHPShopify\ShopifySDK($config);
                    return $shopify;
            }
            else
            {
                abort(404);
            }
        }
        function call_view($installed_webhooks,$uninstalled_webhooks,$results_details,$installed_script,$uninstalled_script)
        {   
            $wheelify = Admin::all();
            return view('backend.pages.wheelify.investigation', compact('wheelify','results_details','installed_webhooks','uninstalled_webhooks','installed_script','uninstalled_script'));  
        }

        function call_webhooks($W_url)
        {
            $webhooks_topic = ['app/uninstalled','products/create','products/update','products/delete','orders/create'];

            $installed_webhooks=$uninstalled_webhooks=$installed_script=$uninstalled_script = [];
            try{   
                $shopify = store($W_url);
                $webhooks = $shopify->Webhook->get();

                foreach($webhooks as $item)
                {
                    if(in_array($item['topic'],$webhooks_topic))
                    {
                        $installed_webhooks[] = $item;
                    }
                }
                $uninstalled_webhooks = array_diff($webhooks_topic, array_column($installed_webhooks, 'topic'));
            
                return call_view($installed_webhooks,$uninstalled_webhooks,$W_url,$installed_script,$uninstalled_script);
            }
            catch (\Exception $e)
            {
                session()->flash('error', 'No Store Exists');
                return back();
            }

        } 
        function del_webhooks($W_del,$store)
        {
            $shopify = store($store);

                    foreach($W_del as $W_id)
                    {
                        $dell_webhooks =$shopify->Webhook($W_id)->delete();
                    }

            session()->flash('success', 'Webhook is uninstalled Successfully');
            return call_webhooks($store);
        }
        function install_webhooks($install_webhooks,$store)
        {
            $shopify = store($store);
            
            foreach($install_webhooks as $item)
            {
                if($item == 'products/delete')
                {
                    $shopify->Webhook->post(array(
                        'topic' => $item,
                        'address' => 'https://app-spinner.carecart.io/shopifyStoreWebhooks/deleteProduct/',
                        'format' => 'json'
                    ));
                }
                if($item == 'orders/create')
                {
                    $shopify->Webhook->post(array(
                        'topic' => $item,
                        'address' => 'https://app-spinner.carecart.io/shopifyStoreWebhooks/createOrder/',
                        'format' => 'json'
                    ));
                }
                if($item == 'products/create')
                {
                    $shopify->Webhook->post(array(
                        'topic' => $item,
                        'address' => 'https://app-spinner.carecart.io/shopifyStoreWebhooks/createProduct/',
                        'format' => 'json'
                    ));
                }
                if($item == 'app/uninstalled')
                {
                    $shopify->Webhook->post(array(
                        'topic' => $item,
                        'address' => 'https://app-spinner.carecart.io/shopifyStoreWebhooks/appUninstall/',
                        'format' => 'json'
                    ));
                }
                if($item == 'products/update')
                {
                    $shopify->Webhook->post(array(
                        'topic' => $item,
                        'address' => 'https://app-spinner.carecart.io/shopifyStoreWebhooks/updateProduct/',
                        'format' => 'json'
                    ));
                }
            }
            session()->flash('success', 'Webhook is installed Successfully');
            return call_webhooks($store);
        }

        function call_js($S_js)
        {
            $script_src = ['https://app-spinner.carecart.io/library/carecartSpinnerApp.js'];
            $installed_webhooks=$uninstalled_webhooks=$installed_script=$uninstalled_script= [];
            try{   
                $shopify = store($S_js);
                    $script = $shopify->ScriptTag->get();
                
                    foreach($script as $item)
                    {
                        // if(in_array($item['src'],$script_src))
                        // {
                            $installed_script[] = $item;
                        // }
                    }
                    $uninstalled_script = array_diff($script_src, array_column($installed_script, 'src'));

                    return call_view($installed_webhooks,$uninstalled_webhooks,$S_js,$installed_script,$uninstalled_script);
            }
            catch (\Exception $e)
            {
                session()->flash('error', 'No Store Exists');
                return back();
            }
        }
        function del_js($js_del,$js_store)
        {
            $shopify = store($js_store); 
            
            foreach($js_del as $S_id)
                    {
                        $dell_js =$shopify->ScriptTag($S_id)->delete();
                    }

            session()->flash('success', 'JS is uninstalled Successfully');
            return call_js($js_store);
        }
        function install_js($js_script,$js_store)
        { 
            
            $shopify = store($js_store);
            foreach($js_script as $script)
            {
                if($script != NULL)
                {
                $srData = array('event' => 'onload', 'src' => $script);
                $allScript = $shopify->ScriptTag->post($srData);
                }
                else
                {
                    
                }
            }
            session()->flash('success', 'JS is installed Successfully');
            return call_js($js_store);
            
        }

        if($W_url)
        {
            return call_webhooks($W_url);
        }
        if($W_del)
        {
            return del_webhooks($W_del,$store);
        }
        if($install_webhooks)
        {
            return install_webhooks($install_webhooks,$store);
        }
        if($S_js)
        {
            return call_js($S_js);
        }
        if($js_del)
        {
            return del_js($js_del,$js_store);
        }
        if($js_script)
        {
            return install_js($js_script,$js_store);
        }
}  

}