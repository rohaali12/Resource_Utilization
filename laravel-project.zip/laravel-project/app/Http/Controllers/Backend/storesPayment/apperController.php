<?php

namespace App\Http\Controllers\Backend\storesPayment;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;

class apperController extends Controller
{

    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $shop_id = $request->input('shop_id');
        $recurring_id = $request->input('recurring_id');

        $store_details = "SELECT `shop` , `access_token` FROM `stores` WHERE id = $shop_id";
        $results_details =  DB::connection('mysql3')->select($store_details);
        

        foreach($results_details as $store){
            $url = $store->shop;
            $token = $store->access_token;
        }

            try{   
                
                $config = array(
                    'ShopUrl' => $url,
                    'AccessToken' => $token,
                    );

                $shopify = new \PHPShopify\ShopifySDK($config);
                $usageCharges[]= $shopify->RecurringApplicationCharge($recurring_id)->UsageCharge->get();    
                
                $salespop = Admin::all(); 
                return view('backend.pages.sales-pop.payment.usagecharge',['usageCharges'=>$usageCharges],compact('salespop'));                                  
                
            }
            catch (\Exception $e)
            {
                session()->flash('error', 'No Store Exists');
                return back();
            }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (is_null($this->user) || !$this->user->can('salespop.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        
        $usageCharges=[];
        $store_details = "SELECT * FROM stores WHERE id = $id";
        $results_details =  DB::connection('mysql3')->select($store_details);
        
        foreach($results_details as $store){
            $url = $store->shop;
            $token = $store->access_token;
        }
        try{   
                                $config = array(
                                                'ShopUrl' => $url,
                                                'AccessToken' => $token,
                                                );
                                $shopify = new \PHPShopify\ShopifySDK($config);
                                
                                $recurringCharges = $shopify->RecurringApplicationCharge->get();

                                $apper = Admin::all(); 
                                return view('backend.pages.apper.payment.recurringcharge',['recurringCharges'=>$recurringCharges,'id'=>$id],compact('apper'));                                
            }
        catch (\Exception $e)
            {
                session()->flash('error', 'No Store Exists');
                return back();
            }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}