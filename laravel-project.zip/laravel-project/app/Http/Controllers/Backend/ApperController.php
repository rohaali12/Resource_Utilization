<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class ApperController extends Controller
{
    
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

// app er dashboard
    function index(){
        if (is_null($this->user) || !$this->user->can('apper.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $query = "SELECT `id` , `shop` , `email` , DATE_FORMAT(`store_installation_datetime` ,'%a, %e %M %Y %H:%i:%s') AS store_installation_datetime , DATE_FORMAT(`app_uninstalled_date_time` ,'%a, %e %M %Y %H:%i:%s') AS app_uninstalled_date_time FROM stores";
        $results = DB::connection('mysql3')->select($query);
        $apper = Admin::all();
        return view('backend.pages.apper.index', ['results' => $results], compact('apper'));
    }

// show store details
    function show($id){
    if (is_null($this->user) || !$this->user->can('apper.view')) {
        abort(403, 'Sorry !! You are Unauthorized to view any admin !');
    }

    $store_details = "SELECT * FROM stores WHERE id = $id";
    $revenue_details = "SELECT Count(*) As clicks , SUM(original_total_price) As revenue FROM `carts`  WHERE `store_id` = $id";
    $revenue30days = "SELECT SUM(original_total_price) As revenue30days   FROM carts WHERE store_id = $id AND created_at BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()";
    $package = "SELECT packages.title,packages.package_detail,packages.price FROM packages JOIN stores ON stores.requested_package_id = packages.id WHERE stores.id = $id";

    $results_details =  DB::connection('mysql3')->select($store_details);
    $results_revenue =  DB::connection('mysql3')->select($revenue_details);
    $results_revenue30days =  DB::connection('mysql3')->select($revenue30days);
    $results_package =   DB::connection('mysql3')->select($package);

    foreach($results_details as $store){
        $url = $store->shop;
        $token = $store->access_token;
    }
    try{   
        $config = array(
                        'ShopUrl' => $url,
                        'AccessToken' => $token,
                        );

        $shopify = new \PHPShopify\ShopifySDK($config);
        $webhooks = $shopify->Webhook->get();

        $status = "active";
    }
    catch (\Exception $e){
        $status = "unrecognized login or wrong password";
    }

        $apper = Admin::all();
        return view('backend.pages.apper.details', ['results_details' => $results_details , 'status' => $status, 'results_revenue' => $results_revenue , 'results_revenue30days' => $results_revenue30days , 'results_package' => $results_package], compact('apper'));
    
    }

// investigation
    function create()
    {
        if (is_null($this->user) || !$this->user->can('apper.investigation')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $installed_webhooks = $uninstalled_webhooks = $installed_script = $uninstalled_script = [];
        $results_details = NULL;
        $apper = Admin::all();
        return view('backend.pages.apper.investigation', ['results_details' => $results_details , 'installed_webhooks' => $installed_webhooks , 'uninstalled_webhooks' => $uninstalled_webhooks , 'installed_script' => $installed_script, 'uninstalled_script' => $uninstalled_script], compact('apper'));
    }
    function store(Request $request)
    { 

        $W_url = $request->input('url_webhooks');
        $W_del = $request->input('webhooks');
        $store = $request->input('W_store');
        $install_webhooks = $request->input('install_webhooks');

        $S_js = $request->input('url_js');
        $js_del = $request->input('js');
        $js_store = $request->input('js_store');
        $js_script = $request->input('script');

            function store($url)
            {
                $store_details = "SELECT `access_token` , `shop` FROM stores WHERE `shop` ='".$url."' OR `domain` = '".$url."'";
                $results_details =  DB::connection('mysql3')->select($store_details);
                
                if($results_details)
                {
                    foreach($results_details as $token){
                        $access_token = $token->access_token;
                    }

                
                    $config = array(
                        'ShopUrl' => $url,
                        'AccessToken' => $access_token,
                    );
                        $shopify = new \PHPShopify\ShopifySDK($config);
                        return $shopify;
                }
                else
                {
                    abort(404);
                }
            }
            function call_view($installed_webhooks,$uninstalled_webhooks,$results_details,$installed_script,$uninstalled_script)
            {   
                $apper = Admin::all();
                return view('backend.pages.apper.investigation', compact('apper','results_details','installed_webhooks','uninstalled_webhooks','installed_script','uninstalled_script'));  
            }

            function call_webhooks($W_url)
            {
                $webhooks_topic = ['app/uninstalled','products/create','products/update','products/delete','orders/create'];

                $installed_webhooks=$uninstalled_webhooks=$installed_script=$uninstalled_script = [];
                try{   
                    $shopify = store($W_url);
                        $webhooks = $shopify->Webhook->get();

                        foreach($webhooks as $item)
                        {
                            if(in_array($item['topic'],$webhooks_topic))
                            {
                                $installed_webhooks[] = $item;
                            }
                        }
                        $uninstalled_webhooks = array_diff($webhooks_topic, array_column($installed_webhooks, 'topic'));
                    
                        return call_view($installed_webhooks,$uninstalled_webhooks,$W_url,$installed_script,$uninstalled_script);
                }
                catch (\Exception $e)
                {
                    session()->flash('error', 'No Store Exists');
                    return back();
                }   
                        
            } 
            function del_webhooks($W_del,$store)
            {
                $shopify = store($store);

                        foreach($W_del as $W_id)
                        {
                            $dell_webhooks =$shopify->Webhook($W_id)->delete();
                        }

                session()->flash('success', 'Webhook is uninstalled Successfully');
                return call_webhooks($store);
            }
            function install_webhooks($install_webhooks,$store)
            {
                $shopify = store($store);
                
                foreach($install_webhooks as $item)
                {
                    if($item == 'products/delete')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://apper.carecart.io/shopifyWebhooks/deleteProduct/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'orders/create')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://apper.carecart.io/shopifyWebhooks/createOrder/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'products/create')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://apper.carecart.io/shopifyWebhooks/createProduct/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'app/uninstalled')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://apper.carecart.io/shopifyWebhooks/appUninstall/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'products/update')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://apper.carecart.io/shopifyWebhooks/updateProduct/',
                            'format' => 'json'
                        ));
                    }
                }
                session()->flash('success', 'Webhook is installed Successfully');
                return call_webhooks($store);
            }

            function call_js($S_js)
            {
                $script_src = ['https://app.carecart.io/api/abandoned-cart/js-script'];
                $installed_webhooks=$uninstalled_webhooks=$installed_script=$uninstalled_script= [];
                try{   
                    $shopify = store($S_js);
                        $script = $shopify->ScriptTag->get();
                        
                        foreach($script as $item)
                        {
                            // if(in_array($item['src'],$script_src))
                            // {
                                $installed_script[] = $item;
                            // }
                        }
                        $uninstalled_script = array_diff($script_src, array_column($installed_script, 'src'));

                        return call_view($installed_webhooks,$uninstalled_webhooks,$S_js,$installed_script,$uninstalled_script);
                }
                catch (\Exception $e)
                {
                    session()->flash('error', 'No Store Exists');
                    return back();
                }    
            }
            function del_js($js_del,$js_store)
            {
                $shopify = store($js_store); 
                
                foreach($js_del as $S_id)
                        {
                            $dell_js =$shopify->ScriptTag($S_id)->delete();
                        }

                session()->flash('success', 'JS is uninstalled Successfully');
                return call_js($js_store);
            }
            function install_js($js_script,$js_store)
            {
                $shopify = store($js_store);
                foreach($js_script as $script)
                {
                    if($script != NULL)
                    {
                    $srData = array('event' => 'onload', 'src' => $script);
                    $allScript = $shopify->ScriptTag->post($srData);
                    }
                    else
                    {
                        
                    }
                }
                
                session()->flash('success', 'JS is installed Successfully');
                return call_js($js_store);
                
            }

            if($W_url)
            {
                return call_webhooks($W_url);
            }
            if($W_del)
            {
                return del_webhooks($W_del,$store);
            }
            if($install_webhooks)
            {
                return install_webhooks($install_webhooks,$store);
            }
            if($S_js)
            {
                return call_js($S_js);
            }
            if($js_del)
            {
                return del_js($js_del,$js_store);
            }
            if($js_script)
            {
                return install_js($js_script,$js_store);
            }
    }  
}