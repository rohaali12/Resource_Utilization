<?php

namespace App\Http\Controllers\Backend\GhostLogin;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\JsonResponse;

class loginController extends Controller
{
    public $user;
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('ghost.login')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $login = Admin::all();
        return view('backend.pages.ghost.login',compact('login'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    
    public function store(Request $request)
    {
        if (is_null($this->user) || !$this->user->can('ghost.login')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        try
        {
            $username = 'support@carecart.io';
			$password = 'm#$p&U[a{ns';

                $app = $request->input('app');
                $shop = $request->input('shop');
                $un = $request->input('userName');
                $pwd = $request->input('password');

			if($un != $username || $pwd != $password) {
				session()->flash('error', 'Invalid Email OR Password');
                return back();
			}
            // apper
            if($app == 'mysql3')
            {
                $store = "SELECT * FROM stores WHERE shop = '".$shop."'";
                $results =  DB::connection('mysql3')->select($store);
                if (count($results) == 0) {
                    session()->flash('error', 'Invalid shop url');
                    return back();
                }

                $store_session = $results[0];
                $store_session->is_onboard = 1;
                $store_session->shop = $shop;
                session(['store_session'=>$store_session]);
                // dd(session('store_session'));
                // $newUrl = url('https://app-ar.carecart.io/?shop='.$store_session->shop);
                $newUrl = url('https://new-app-er.carecart.io/?shop='.$store_session->shop);
            }
            // salespop
            if($app == 'mysql2')
            {
                $store = "SELECT * FROM tbl_stores WHERE `url` = '".$shop."'";
                $results =  DB::connection('mysql2')->select($store);
                if (count($results) == 0) {
                    session()->flash('error', 'Invalid shop url');
                    return back();
                }
                
                $store_session = $results[0];
                $store_session->on_boarding = 1;
                $store_session->url = $shop;
                session(['store_session'=>$store_session]);
                // dd(session('store_session'));
                $newUrl = url('https://dev-sales-pop.carecart.io/dashboard-new?shop='.$store_session->url);
                // $newUrl = url('https://bright-dodo-9.telebit.io/dashboard-new?shop='.$store_session->url);
                // $newUrl = url('https://sales-pop.carecart.io/dashboard-new?shop='.$store_session->url);
                
            }
            // wheelify
            if($app == 'mysql4')
            {
                $store = "SELECT * FROM stores WHERE shop = '".$shop."'";
                $results =  DB::connection('mysql4')->select($store);
                if (count($results) == 0) {
                    session()->flash('error', 'Invalid shop url');
                    return back();
                }
                $store_session = $results[0];
                $store_session->is_onboard = 1;
			    $store_session->shop = $shop;
                session(['store_session'=>$store_session]);
                // dd(session('store_session'));
                // $newUrl = url('https://app-spinner.carecart.io/spin-a-sale-newui/analytics?shop='.$store_session->shop);
                $newUrl = url('https://bright-dodo-9.telebit.io/spin-a-sale-newui/analytics?shop='.$store_session->shop);
            }
            // ab protector
            if($app == 'mysql5')
            {
                $store = "SELECT * FROM stores WHERE shop = '".$shop."'";
                $results =  DB::connection('mysql5')->select($store);
                if (count($results) == 0) {
                    session()->flash('error', 'Invalid shop url');
                    return back();
                }
                $store_session = $results[0];
                $store_session->is_onboard = 1;
                $store_session->shop = $shop;
                session(['store_session'=>$store_session]);
                // dd(session('store_session'));
                $newUrl = url('https://app-cart-reminder.carecart.io/cart-reminder/?shop='.$store_session->shop);
            }

            $resp = [
				'_metadata' => [
					'outcome' => 'SUCCESS',
					'outcomeCode' => 0,
					'numOfRecords' => 1,
					'message' => 'Store session created successfully',
				],
				'records' => [
					'url' => $newUrl
				],
				'errors' => [],
			];
            
			header('Content-Type: application/json');
			echo json_encode($resp);
			exit;
        }
        catch(Exception $ex) 
        {
            $resp = [
				'_metadata' => [
					'outcome' => 'INVALID_CREDENTIALS',
					'outcomeCode' => 3,
					'numOfRecords' => 0,
					'message' => $ex->getMessage(),
				],
				'records' => [],
				'errors' => [],
			];
            header('Content-Type: application/json');
			echo json_encode($resp);
			exit;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}