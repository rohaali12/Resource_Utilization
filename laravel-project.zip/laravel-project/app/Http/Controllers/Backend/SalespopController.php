<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;



class SalespopController extends Controller
{
    
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

// salespop dashboard
    function index(){
        if (is_null($this->user) || !$this->user->can('salespop.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $query = "SELECT `id` , `store_id` , `url`, `email`, DATE_FORMAT(`app_install_date` ,'%a, %e %M %Y %H:%i:%s') AS app_install_date , DATE_FORMAT(`app_uninstall_date` ,'%a, %e %M %Y %H:%i:%s') AS app_uninstall_date  FROM tbl_stores";
        $results = DB::connection('mysql2')->select($query);
        
        $salespop = Admin::all();
        return view('backend.pages.sales-pop.index', ['results' => $results], compact('salespop'));
    }
    
// show store details
    function show($id){
        if (is_null($this->user) || !$this->user->can('salespop.view')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $store_details = "SELECT * FROM tbl_stores WHERE store_id = $id";
    
        $module_quick = "SELECT on_off AS quick_status FROM tbl_quick_view_settings WHERE store_id = $id";
        $module_sharecart = "SELECT on_off AS sharecart_status FROM tbl_sharecart_settings WHERE store_id = $id";
        $module_sold = "SELECT on_off AS sold_status FROM tbl_sold_counter_settings WHERE store_id = $id";
        $module_stickycart = "SELECT on_off AS stickycart_status FROM tbl_stickycart_settings WHERE store_id = $id";
        $module_stock = "SELECT on_off AS stock_status FROM tbl_stock_count_down_settings WHERE store_id = $id";
        $module_timer = "SELECT on_off AS timer_status FROM tbl_time_count_down_settings WHERE store_id = $id";
        $module_trust = "SELECT on_off AS trust_status FROM tbl_trust_badges_settings WHERE store_id = $id";
        $module_visitor = "SELECT on_off AS visitor_status FROM tbl_visitor_counter_settings WHERE store_id = $id";
        $module_annoucement = "SELECT on_off AS annoucement_status FROM tbl_announcement_bar_settings WHERE store_id = $id";

        $revenue = "SELECT Count(*) As clicks , SUM(revenue_generated) As revenue   FROM tbl_click_history WHERE store_id = $id";
        $revenue30days = "SELECT SUM(revenue_generated) As revenue30days   FROM tbl_click_history WHERE store_id = $id AND created_date BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW()";
        
        $package = "SELECT title,package_detail,price FROM tbl_stores JOIN packages ON tbl_stores.package_id = packages.id WHERE store_id = $id";

        $results_details =  DB::connection('mysql2')->select($store_details);
        $results_quick =  DB::connection('mysql2')->select($module_quick);
        $results_sharecart =  DB::connection('mysql2')->select($module_sharecart);
        $results_sold =  DB::connection('mysql2')->select($module_sold);
        $results_stickycart =  DB::connection('mysql2')->select($module_stickycart);
        $results_stock =  DB::connection('mysql2')->select($module_stock);
        $results_timer =  DB::connection('mysql2')->select($module_timer);
        $results_trust =  DB::connection('mysql2')->select($module_trust);
        $results_visitor =  DB::connection('mysql2')->select($module_visitor);
        $results_annoucment =  DB::connection('mysql2')->select($module_annoucement);

        $results_package =   DB::connection('mysql2')->select($package);
        $results_revenue =  DB::connection('mysql2')->select($revenue);
        $results_revenue30days =  DB::connection('mysql2')->select($revenue30days);
        
        foreach($results_details as $store){
            $url = $store->url;
            $token = $store->access_token;
        }

        try{   
                            $config = array(
                                            'ShopUrl' => $url,
                                            'AccessToken' => $token,
                                            );
                            $shopify = new \PHPShopify\ShopifySDK($config);
                            $webhooks = $shopify->Webhook->get();

                            $status = "active";
            }
            catch (\Exception $e){
                            $status = "unrecognized login or wrong password";
            }
            $salespop = Admin::all();
            return view('backend.pages.sales-pop.details', ['status' => $status ,'results_details' => $results_details,'results_quick' => $results_quick,'results_sharecart' => $results_sharecart,'results_sold' => $results_sold,'results_stickycart' => $results_stickycart,'results_stock' => $results_stock,'results_timer' => $results_timer,'results_trust' => $results_trust,'results_visitor' => $results_visitor,'results_annoucment' => $results_annoucment,'results_revenue' => $results_revenue,'results_revenue30days' => $results_revenue30days,'results_package' => $results_package], compact('salespop'));
        
    }

// investigation
    function create()
    {
        if (is_null($this->user) || !$this->user->can('salespop.investigation')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $installed_webhooks = $uninstalled_webhooks = $installed_script = $uninstalled_script = [];
        $results_details = NULL;
        $salespop = Admin::all();
        return view('backend.pages.sales-pop.investigation', ['results_details' => $results_details , 'installed_webhooks' => $installed_webhooks , 'uninstalled_webhooks' => $uninstalled_webhooks , 'installed_script' => $installed_script, 'uninstalled_script' => $uninstalled_script], compact('salespop'));
    }
    function store(Request $request)
    { 

        $W_url = $request->input('url_webhooks');
        $W_del = $request->input('webhooks');
        $store = $request->input('W_store');
        $install_webhooks = $request->input('install_webhooks');

        $S_js = $request->input('url_js');
        $js_del = $request->input('js');
        $js_store = $request->input('js_store');
        $js_script = $request->input('script');

        // $validation = $request->validate([
        //     'url_webhooks' => 'required',
        //     'url_js' => 'required',
        // ]);
            function store($url)
            {
                $store_details = "SELECT `access_token` , `url` FROM tbl_stores WHERE `url` ='".$url."' OR `domain` = '".$url."'";
                $results_details =  DB::connection('mysql2')->select($store_details);

                if($results_details != NULL)
                {
                    foreach($results_details as $token){
                        $access_token = $token->access_token;
                    }

                    $config = array(
                        'ShopUrl' => $url,
                        'AccessToken' => $access_token,
                    );
                        $shopify = new \PHPShopify\ShopifySDK($config);
                        return $shopify;
                }
                else
                {
                    session()->flash('error', 'No Store Exists');
                    return back();
                }
            }
            function call_view($installed_webhooks,$uninstalled_webhooks,$results_details,$installed_script,$uninstalled_script)
            {   
                $salespop = Admin::all();
                return view('backend.pages.sales-pop.investigation', compact('salespop','results_details','installed_webhooks','uninstalled_webhooks','installed_script','uninstalled_script'));  
            }

            function call_webhooks($W_url)
            {
                $webhooks_topic = ['app/uninstalled','products/create','products/update','products/delete','orders/create'];

                $installed_webhooks=$uninstalled_webhooks=$installed_script=$uninstalled_script = [];
                        try{   
                            $shopify = store($W_url);
                            $webhooks = $shopify->Webhook->get();

                            foreach($webhooks as $item)
                            {
                                if(in_array($item['topic'],$webhooks_topic))
                                {
                                    $installed_webhooks[] = $item;
                                }
                            }
                            $uninstalled_webhooks = array_diff($webhooks_topic, array_column($installed_webhooks, 'topic'));
                            
                            return call_view($installed_webhooks,$uninstalled_webhooks,$W_url,$installed_script,$uninstalled_script);
                        }
                        catch (\Exception $e)
                        {
                            session()->flash('error', 'No Store Exists');
                            return back();
                        }          
            } 
            function del_webhooks($W_del,$store)
            {
                $shopify = store($store);

                        foreach($W_del as $W_id)
                        {
                            $dell_webhooks =$shopify->Webhook($W_id)->delete();
                        }

                session()->flash('success', 'Webhook is uninstalled Successfully');
                return call_webhooks($store);
            }
            function install_webhooks($install_webhooks,$store)
            {
                $shopify = store($store);
                
                foreach($install_webhooks as $item)
                {
                    if($item == 'products/delete')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://sales-pop.carecart.io/shopifyWebhooks/deleteProduct/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'orders/create')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://sales-pop.carecart.io/shopifyWebhooks/createOrder/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'products/create')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://sales-pop.carecart.io/shopifyWebhooks/createProduct/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'app/uninstalled')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://sales-pop.carecart.io/shopifyWebhooks/appUninstall/',
                            'format' => 'json'
                        ));
                    }
                    if($item == 'products/update')
                    {
                        $shopify->Webhook->post(array(
                            'topic' => $item,
                            'address' => 'https://sales-pop.carecart.io/shopifyWebhooks/updateProduct/',
                            'format' => 'json'
                        ));
                    }
                }
                session()->flash('success', 'Webhook is installed Successfully');
                return call_webhooks($store);
            }

            function call_js($S_js)
            {
                $script_src = ['https://sales-pop.carecart.io/lib/salesnotifier.js'];
                $installed_webhooks=$uninstalled_webhooks=$installed_script=$uninstalled_script= [];
                try{   
                    $shopify = store($S_js);
                        $script = $shopify->ScriptTag->get();

                        foreach($script as $item)
                        {
                            // if(in_array($item['src'],$script_src))
                            // {
                                $installed_script[] = $item;
                            // }
                        }
                        $uninstalled_script = array_diff($script_src, array_column($installed_script, 'src'));

                        return call_view($installed_webhooks,$uninstalled_webhooks,$S_js,$installed_script,$uninstalled_script);
                }
                catch (\Exception $e)
                {
                    session()->flash('error', 'No Store Exists');
                    return back();
                }
            }
            function del_js($js_del,$js_store)
            {
                $shopify = store($js_store); 
                
                foreach($js_del as $S_id)
                        {
                            $dell_js =$shopify->ScriptTag($S_id)->delete();
                        }
                
                session()->flash('success', 'JS is uninstalled Successfully');
                return call_js($js_store);
            }
            function install_js($js_script,$js_store)
            {
                $shopify = store($js_store);
                foreach($js_script as $script)
                {
                    if($script != NULL)
                    {
                    $srData = array('event' => 'onload', 'src' => $script);
                    $allScript = $shopify->ScriptTag->post($srData);
                    }
                    else
                    {
                        
                    }
                }
                
                session()->flash('success', 'JS is installed Successfully');
                return call_js($js_store);
                
            }

            if($W_url)
            {
                return call_webhooks($W_url);
            }
            if($W_del)
            {
                return del_webhooks($W_del,$store);
            }
            if($install_webhooks)
            {
                return install_webhooks($install_webhooks,$store);
            }
            if($S_js)
            {
                return call_js($S_js);
            }
            if($js_del)
            {
                return del_js($js_del,$js_store);
            }
            if($js_script)
            {
                return install_js($js_script,$js_store);
            }
    } 
    
}