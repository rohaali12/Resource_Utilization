<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;

class salespopProductsController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('salespop.update')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        
        $salespop = Admin::all();
        return view('backend.pages.sales-pop.products', compact('salespop'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $url = $request->input('url');
        // $product = $request->input('product');
        $cdn = $request->input('cdn');

        $validatedData = $request->validate([
            'url' => 'required',
            // 'product' => 'required',
            'cdn' => 'required',
        ]);
                $store_details = "SELECT `store_id` FROM tbl_stores WHERE `url` = '".$url."' ";
                $results1_id =  DB::connection('mysql2')->select($store_details);
                foreach($results1_id as $key){$id1 = $key;}

                $product_details = "SELECT `product_id` FROM tbl_products WHERE `image` = '".$cdn."' AND `id` = $id1->store_id ";
                $results_details =  DB::connection('mysql2')->select($product_details);
                foreach($results_details as $key){$product1 = $key;}

                if($results1_id)
                {
                    if($results_details)
                    {
                        $update_product = "UPDATE `tbl_salespop` SET `product_image` = '".$cdn."' WHERE `product_id` = $product1->product_id";
                        $result_update =  DB::connection('mysql2')->select($update_product);
                        session()->flash('success', 'CDN Updated Successfully');
                        return back();
                    }
                    else
                    {
                        session()->flash('error', 'Product Doesnot Exists');
                        return back();
                    }
                }
                else
                {
                    session()->flash('error', 'Store Doesnot Exists');
                    return back();
                }
                
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}