<?php

namespace App\Http\Controllers\Backend\compareStores;

use App\Http\Controllers\Controller;
use App\User;
use App\Models\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;

class compareStoresController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    } 
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('campare.store')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
        $results_details1 = $results_details2 = [];
        $compareStore = Admin::all();
        return view('backend.pages.compareStore.index', ['results_details1' => $results_details1 , 'results_details2' => $results_details2], compact('compareStore'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $app = $request->input('app');
        $store1 = $request->input('store1');
        $store2 = $request->input('store2');

        $validation = $request->validate([
            'app' => 'required',
            'store1' => 'required',
            'store2' => 'required',
        ]);


        function salespop($store1,$store2)
        {
            $salespop = TRUE;
            $apper = FALSE;
            $wheelify = FALSE;

            $store1_id = "SELECT `store_id` FROM tbl_stores WHERE `url` = '".$store1."'";
            $results1_id =  DB::connection('mysql2')->select($store1_id);
            if($results1_id != NULL)
            {
                foreach($results1_id as $key){$id1 = $key;}
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
            

            $store1_details = "SELECT `store_name` AS `store_name` , `url` AS `url` , `email` AS `email` , `shop_owner` AS `shop_owner` , `shopify_plan_display_name` AS `shopify_plan_name` , `currency` AS `currency` , `app_uninstall_date` AS `app_uninstall_date` FROM tbl_stores WHERE `url` = '".$store1."'";
            $module1_quick = "SELECT * FROM tbl_quick_view_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_sharecart = "SELECT * FROM tbl_sharecart_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_sold = "SELECT * FROM tbl_sold_counter_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_stickycart = "SELECT * FROM tbl_stickycart_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_stock = "SELECT * FROM tbl_stock_count_down_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_timer = "SELECT * FROM tbl_time_count_down_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_trust = "SELECT * FROM tbl_trust_badges_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_visitor = "SELECT * FROM tbl_visitor_counter_settings WHERE `store_id` = '".$id1->store_id."'";
            $module1_annoucement = "SELECT * FROM tbl_announcement_bar_settings WHERE `store_id` = '".$id1->store_id."'";

            $results_details1['basic'] =  DB::connection('mysql2')->select($store1_details);
            $results_details1['module_quick'] =  DB::connection('mysql2')->select($module1_quick);
            $results_details1['module_sharecart'] =  DB::connection('mysql2')->select($module1_sharecart);
            $results_details1['module_sold'] =  DB::connection('mysql2')->select($module1_sold);
            $results_details1['module_stickycart'] =  DB::connection('mysql2')->select($module1_stickycart);
            $results_details1['module_stock'] =  DB::connection('mysql2')->select($module1_stock);
            $results_details1['module_timer'] =  DB::connection('mysql2')->select($module1_timer);
            $results_details1['module_trust'] =  DB::connection('mysql2')->select($module1_trust);
            $results_details1['module_visitor'] =  DB::connection('mysql2')->select($module1_visitor);
            $results_details1['module_annoucement'] =  DB::connection('mysql2')->select($module1_annoucement);

            $store2_id = "SELECT `store_id` FROM tbl_stores WHERE `url` = '".$store1."'";
            $results2_id =  DB::connection('mysql2')->select($store2_id);
            if($results2_id != NULL)
            {
                foreach($results2_id as $key){$id2 = $key;}
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
            

            $store2_details = "SELECT `store_name` AS `store_name` , `url` AS `url` , `email` AS `email` , `shop_owner` AS `shop_owner` , `shopify_plan_display_name` AS `shopify_plan_name` , `currency` AS `currency` , `app_uninstall_date` AS `app_uninstall_date` FROM tbl_stores WHERE `url` = '".$store2."'";
            $module2_quick = "SELECT * FROM tbl_quick_view_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_sharecart = "SELECT * FROM tbl_sharecart_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_sold = "SELECT * FROM tbl_sold_counter_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_stickycart = "SELECT * FROM tbl_stickycart_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_stock = "SELECT * FROM tbl_stock_count_down_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_timer = "SELECT * FROM tbl_time_count_down_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_trust = "SELECT * FROM tbl_trust_badges_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_visitor = "SELECT * FROM tbl_visitor_counter_settings WHERE `store_id` = '".$id2->store_id."'";
            $module2_annoucement = "SELECT * FROM tbl_announcement_bar_settings WHERE `store_id` = '".$id2->store_id."'";

            $results_details2['basic'] =  DB::connection('mysql2')->select($store2_details);
            $results_details2['module_quick'] =  DB::connection('mysql2')->select($module2_quick);
            $results_details2['module_sharecart'] =  DB::connection('mysql2')->select($module2_sharecart);
            $results_details2['module_sold'] =  DB::connection('mysql2')->select($module2_sold);
            $results_details2['module_stickycart'] =  DB::connection('mysql2')->select($module2_stickycart);
            $results_details2['module_stock'] =  DB::connection('mysql2')->select($module2_stock);
            $results_details2['module_timer'] =  DB::connection('mysql2')->select($module2_timer);
            $results_details2['module_trust'] =  DB::connection('mysql2')->select($module2_trust);
            $results_details2['module_visitor'] =  DB::connection('mysql2')->select($module2_visitor);
            $results_details2['module_annoucement'] =  DB::connection('mysql2')->select($module2_annoucement);

            // dd($results_details1,$results_details2);
            if(($results_details1 != NULL) && ($results_details2 != NULL))
            {
                $compareStore = Admin::all();
                return view('backend.pages.compareStore.index', ['results_details1' => $results_details1 , 'results_details2' => $results_details2 , 'salespop' => $salespop, 'apper' => $apper, 'wheelify' => $wheelify], compact('compareStore'));
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
        }
        
        function apper($store1,$store2)
        {
            $apper = TRUE;
            $salespop = FALSE;
            $wheelify = FALSE;

            $store_details1 = "SELECT `name` AS `store_name` , `shop` AS `url` , `email` AS `email` , `shop_owner` AS `shop_owner` , `plan_display_name` AS `shopify_plan_name` , `currency` AS `currency`  , `app_uninstalled_date_time` AS `app_uninstall_date` , `emails_paused_date_time` As `abandoned` , `followup_emails_paused_date_time` As `followup` FROM stores WHERE `shop` = '".$store1."'";
            $results_details1['basic'] =  DB::connection('mysql3')->select($store_details1);

            $store_details2 = "SELECT `name` AS `store_name` , `shop` AS `url` , `email` AS `email` , `shop_owner` AS `shop_owner` , `plan_display_name` AS `shopify_plan_name` , `currency` AS `currency`  , `app_uninstalled_date_time` AS `app_uninstall_date` ,  `emails_paused_date_time` As `abandoned` , `followup_emails_paused_date_time` As `followup` FROM stores WHERE `shop` = '".$store2."'";
            $results_details2['basic'] =  DB::connection('mysql3')->select($store_details2);

            $store1_id = "SELECT `id` FROM stores WHERE `shop` = '".$store1."'";
            $results1_id =  DB::connection('mysql3')->select($store1_id);
            if($results1_id != NULL)
            {
                foreach($results1_id as $key){$id1 = $key;}
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
            
            $store1_details = "SELECT * FROM `email_templates` WHERE `store_id` = $id1->id";
            $results_details1['module'] =  DB::connection('mysql3')->select($store1_details);

            $store2_id = "SELECT `id` FROM stores WHERE `shop` = '".$store2."'";
            $results2_id =  DB::connection('mysql3')->select($store2_id);
            if($results2_id != NULL)
            {
                foreach($results2_id as $key){$id2 = $key;}
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
            
            $store2_details = "SELECT * FROM `email_templates` WHERE `store_id` = $id2->id";
            $results_details2['module'] =  DB::connection('mysql3')->select($store2_details);

            if(($results_details1 != NULL) && ($results_details2 != NULL))
            {
                $compareStore = Admin::all();
                return view('backend.pages.compareStore.index', ['results_details1' => $results_details1 , 'results_details2' => $results_details2 , 'salespop' => $salespop, 'apper' => $apper, 'wheelify' => $wheelify], compact('compareStore'));
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
        }

        function wheelify($store1,$store2)
        {
            $wheelify = TRUE;
            $salespop = FALSE;
            $apper = FALSE;

            $store_details1 = "SELECT `name` AS `store_name` , `shop` AS `url` , `email` AS `email` , `shop_owner` AS `shop_owner` , `plan_display_name` AS `shopify_plan_name` , `currency` AS `currency`  , `app_uninstalled_date_time` AS `app_uninstall_date`  FROM stores WHERE `shop` = '".$store1."'";
            $results_details1['basic'] =  DB::connection('mysql4')->select($store_details1);

            $store_details2 = "SELECT `name` AS `store_name` , `shop` AS `url` , `email` AS `email` , `shop_owner` AS `shop_owner` , `plan_display_name` AS `shopify_plan_name` , `currency` AS `currency`  , `app_uninstalled_date_time` AS `app_uninstall_date`  FROM stores WHERE `shop` = '".$store2."'";
            $results_details2['basic'] =  DB::connection('mysql4')->select($store_details2);

            $store1_id = "SELECT `id` FROM stores WHERE `shop` = '".$store1."'";
            $results1_id =  DB::connection('mysql4')->select($store1_id);
            if($results1_id != NULL)
            {
                foreach($results1_id as $key){$id2 = $key;}
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
            $store1_details = "SELECT * FROM `spin_a_sale_settings` WHERE `store_id` = $id1->id";
            $results_details1['module'] =  DB::connection('mysql4')->select($store1_details);

            $store2_id = "SELECT `id` FROM stores WHERE `shop` = '".$store2."'";
            $results2_id =  DB::connection('mysql4')->select($store2_id);
            if($results2_id != NULL)
            {
                foreach($results2_id as $key){$id2 = $key;}
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
            
            $store2_details = "SELECT * FROM `spin_a_sale_settings` WHERE `store_id` = $id2->id";
            $results_details2['module'] =  DB::connection('mysql4')->select($store2_details);

            if(($results_details1 != NULL) && ($results_details2 != NULL))
            {
                $compareStore = Admin::all();
                return view('backend.pages.compareStore.index', ['results_details1' => $results_details1 , 'results_details2' => $results_details2, 'salespop' => $salespop, 'apper' => $apper, 'wheelify' => $wheelify], compact('compareStore'));
            }
            else
            {
                session()->flash('error', 'Store doesnot exist');
                return back();
            }
        }

        if($validation)
        {
            if($app == 'mysql2')
            {
                return salespop($store1,$store2);
            }
            if($app == 'mysql3')
            {
                return apper($store1,$store2);
            }
            if($app == 'mysql4')
            {
                return wheelify($store1,$store2);
            }

            
        }     
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}