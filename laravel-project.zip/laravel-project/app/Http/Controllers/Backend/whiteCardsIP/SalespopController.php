<?php

namespace App\Http\Controllers\Backend\whiteCardsIP;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;

class SalespopController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $query_salespop = "SELECT * FROM `white_card_ips`";
        $results_salespop = DB::connection('mysql2')->select($query_salespop);

        $whitecardIP = Admin::all();

        return view('backend.pages.whitecardIP.salespop', ['results_salespop' => $results_salespop], compact('whitecardIP'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function store(Request $request)
    {
            $salespop = $request->input('inputIP_salespop');
            $currentDate = date('Y-m-d');
            
            $validation = $request->validate([
                'inputIP_salespop' => 'required|max:15',
            ]);
        
            if($validation)
            {
                $insert_ip_query = "INSERT INTO `white_card_ips` (ip,created_at) VALUES ('".$salespop."','".$currentDate."')";
                $result_salespop =  DB::connection('mysql2')->select($insert_ip_query);
    
                    session()->flash('success', 'New  IP is addedd');
                    return Redirect::back();
            }
    }

    
    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $results_apper = $results_wheelify = [];

        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $salespop = "SELECT * FROM `white_card_ips` WHERE id = $id";
        $results_salespop =  DB::connection('mysql2')->select($salespop);

        return view('backend.pages.whitecardIP.whitelist_edit',['results_salespop' => $results_salespop, 'results_apper' => $results_apper , 'results_wheelify' => $results_wheelify]);
    }
    public function update(Request $request,$id)
    {
        $validation = $request->validate([
            'inputIP_salespop' => 'required',
        ]);

        if($validation)
        {
            $new_ip = $request->inputIP_salespop;

            $update_query = "UPDATE `white_card_ips` SET ip = '".$new_ip."'  WHERE id = $id";
            $results_update =  DB::connection('mysql2')->select($update_query);
            

            session()->flash('success', 'IP is updated');
            return Redirect('admin/salespopIP');
        }
        

    }

// delete whitelist IP
function destroy($id)
{
    if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
        abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
    }
    $salespop = "DELETE FROM `white_card_ips` WHERE id = $id";
    $results_salespop = DB::connection('mysql2')->select($salespop);

    session()->flash('success', 'IP is deleted');
    return Redirect::back();
}  
}
