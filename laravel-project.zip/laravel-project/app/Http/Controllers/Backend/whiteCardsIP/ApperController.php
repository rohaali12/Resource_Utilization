<?php

namespace App\Http\Controllers\Backend\whiteCardsIP;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;

class ApperController extends Controller
{ 
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }
    public function index()
    {
        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $query_apper = "SELECT * FROM `white_card_ips`";
        $results_apper = DB::connection('mysql3')->select($query_apper);

        $whitecardIP = Admin::all();

        return view('backend.pages.whitecardIP.apper', ['results_apper' => $results_apper], compact('whitecardIP'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $apper = $request->input('inputIP_apper');
        $currentDate = date('Y-m-d');

        $validation = $request->validate([
            'inputIP_apper' => 'required',
        ]);
        
                if($validation)
                {
                    $insert_ip_query = "INSERT INTO `white_card_ips` (ip,created_at) VALUES ('".$apper."','".$currentDate."')";
                    $result_apper =  DB::connection('mysql3')->select($insert_ip_query);
        
                        session()->flash('success', 'New  IP is addedd');
                        return Redirect::back();
                }
    }
    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        $results_salespop = $results_wheelify = [];

        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $apper = "SELECT * FROM `white_card_ips` WHERE id = $id";
        $results_apper =  DB::connection('mysql3')->select($apper);

        return view('backend.pages.whitecardIP.whitelist_edit',['results_salespop' => $results_salespop, 'results_apper' => $results_apper , 'results_wheelify' => $results_wheelify]);
    }
    public function update(Request $request,$id)
    {
        $validation = $request->validate([
            'inputIP_apper' => 'required',
        ]);

        if($validation)
        {
            $new_ip = $request->inputIP_apper;

            $update_query = "UPDATE `white_card_ips` SET ip = '".$new_ip."'  WHERE id = $id";
            $results_update =  DB::connection('mysql3')->select($update_query);
            
            session()->flash('success', 'IP is updated');
            return Redirect('admin/apperIP');
        }
        

    }    

function destroy($id)
{
    if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
        abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
    }
    $apper = "DELETE FROM `white_card_ips` WHERE id = $id";
    $results_apper = DB::connection('mysql3')->select($apper);

    session()->flash('success', 'IP is deleted');
    return back();
}
}
