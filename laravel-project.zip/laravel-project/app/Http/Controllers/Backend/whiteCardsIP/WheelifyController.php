<?php

namespace App\Http\Controllers\Backend\whiteCardsIP;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Models\Admin;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\Redirect;


class WheelifyController extends Controller
{
    public $user;

    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            $this->user = Auth::guard('admin')->user();
            return $next($request);
        });
    }

    public function index()
    {
        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }

        $query_wheelify = "SELECT * FROM `white_card_ips`";
        $results_wheelify = DB::connection('mysql4')->select($query_wheelify);

        $whitelistIP = Admin::all();

        return view('backend.pages.whitecardIP.wheelify', ['results_wheelify' => $results_wheelify], compact('whitelistIP'));
    }
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $wheelify = $request->input('inputIP_wheelify');
        $currentDate = date('Y-m-d');

        $validation = $request->validate([
            'inputIP_wheelify' => 'required',
        ]);
            if($validation)
            {
                $insert_ip_query = "INSERT INTO `white_card_ips` (ip,created_at) VALUES ('".$wheelify."','".$currentDate."')";
                $result_wheelify =  DB::connection('mysql4')->select($insert_ip_query);
    
                    session()->flash('success', 'New  IP is addedd');
                    return Redirect::back();
            }
    }
    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $results_salespop = $results_apper = [];
    
        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to view any admin !');
        }
    
        $wheelify = "SELECT * FROM `white_card_ips` WHERE id = $id";
        $results_wheelify =  DB::connection('mysql4')->select($wheelify);
    
        return view('backend.pages.whitecardIP.whitelist_edit',['results_salespop' => $results_salespop, 'results_apper' => $results_apper , 'results_wheelify' => $results_wheelify]);
    }
    public function update(Request $request,$id)
    {
        $validation = $request->validate([
            'inputIP_wheelify' => 'required',
        ]);
    
        if($validation)
        {
            $new_ip = $request->inputIP_wheelify;
    
            $update_query = "UPDATE `white_card_ips` SET ip = '".$new_ip."'  WHERE id = $id";
            $results_update =  DB::connection('mysql4')->select($update_query);
            
            session()->flash('success', 'IP is updated');
            return Redirect('admin/wheelifyIP');
        }
        
    
    } 
    // delete whitelist IP
    function destroy($id)
    {
        if (is_null($this->user) || !$this->user->can('ip.whitelist')) {
            abort(403, 'Sorry !! You are Unauthorized to delete any admin !');
        }
        $wheelify = "DELETE FROM `white_card_ips` WHERE id = $id";
        $results_wheelify = DB::connection('mysql4')->select($wheelify);
    
        session()->flash('success', 'IP is deleted');
        return back();
    } 
}
