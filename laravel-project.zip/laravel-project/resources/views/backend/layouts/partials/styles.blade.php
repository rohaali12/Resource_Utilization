<link rel="shortcut icon" type="image/png" href="{{ asset('backend/assets/images/icon/favicon.ico') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/font-awesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/themify-icons.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/metisMenu.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/slicknav.min.css') }}">
<!-- amchart css -->
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
<!-- others css -->
<link rel="stylesheet" href="{{ asset('backend/assets/css/typography.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/default-css.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/styles.css') }}">
<link rel="stylesheet" href="{{ asset('backend/assets/css/responsive.css') }}">
<!-- modernizr css -->
<script src="{{ asset('backend/assets/js/vendor/modernizr-2.8.3.min.js') }}"></script>
<style>
.font_size {
    font-size: 13px;
}

.container {
    width: 80%;
    max-width: 600px;
    margin: 50px auto;
}

button.accordion {
    width: 100%;
    background-color: whitesmoke;
    border: none;
    outline: none;
    text-align: left;
    padding: 15px 20px;
    font-size: 18px;
    color: #333;
    cursor: pointer;
    transition: background-color 0.2s linear;
}

button.accordion:after {
    font-family: FontAwesome;
    content: "\f150";
    font-family: "fontawesome";
    font-size: 18px;
    float: right;
}

button.accordion.is-open:after {
    content: "\f151";
}

button.accordion:hover,
button.accordion.is-open {
    background-color: #ddd;
}

.accordion-content {
    background-color: white;
    border-left: 1px solid whitesmoke;
    border-right: 1px solid whitesmoke;
    padding: 0 20px;
    max-height: 0;
    height:auto;
    overflow: hidden;
    transition: max-height 0.2s ease-in-out;
}
</style>