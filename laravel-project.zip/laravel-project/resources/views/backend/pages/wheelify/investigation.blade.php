@extends('backend.layouts.master')

@section('title')
wheelify-Dashboard
@endsection

@section('styles')
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Wheelify</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>investigation</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">
    <div class="row m-3">
        <div class="col-12">
            @include('backend.layouts.partials.messages')
        </div>
        <!-- WEBHOOK START -->
        <div class="col-12">
            <div class="card m-2">
                <div class="card-body">
                    <!-- /.details -->
                    <div class="col-12 card">
                        <div class="card-title">
                            <div class="h4">Webhooks</div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="{{ route('admin.wheelify.store') }}" name="call_webhooks"
                                class="d-flex">
                                @csrf
                                <input type="text" id="url" name="url_webhooks" class="form-control"
                                    placeholder="Enter Your Store URL" />
                                <button type="submit" class="btn btn-primary">Check</button>
                            </form>
                            @if(!is_null($installed_webhooks) && count($installed_webhooks) > 0 )
                            <div class="list-group">
                                <div class="h6 text-center m-3 text-success">Installed webhooks are:</div>
                                <form method="POST" action="{{ route('admin.wheelify.store') }}" name="delete_webhooks">
                                    @csrf
                                    <input class="form-control text-center" type="text" name="W_store"
                                        value="{{ $results_details }}" readonly>
                                    @foreach($installed_webhooks as $item_install)
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                value="{{ $item_install['id'] }}" id="flexCheckDefault"
                                                name="webhooks[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                {{ $item_install['topic'] }}
                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#198754"
                                            class="bi bi-check-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                                        </svg>
                                    </div>
                                    @endforeach
                                    <button type="submit" class="btn btn-danger float-right m-1 show_confirm">Delete</button>
                                </form>
                                @endif
                                @if(!is_null($uninstalled_webhooks) && count($uninstalled_webhooks) > 0)
                                <form method="POST" action="{{ route('admin.wheelify.store') }}" name="install_webhook">
                                    @csrf
                                    <input class="form-control text-center" type="text" name="W_store"
                                        value="{{ $results_details }}" readonly>
                                    @foreach($uninstalled_webhooks as $item_uninstall)
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                value="{{ $item_uninstall }}" id="flexCheckDefault"
                                                name="install_webhooks[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                {{ $item_uninstall}}
                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#C82333"
                                            class="bi bi-x-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                        </svg>
                                    </div>
                                    @endforeach
                                    <button type="submit" class="btn btn-success float-right m-1">Install</button>
                                </form>
                            </div>
                            @endif
                        </div>
                    </div>
                    <!-- /.details -->
                </div>
            </div>
        </div>
        <!-- WEBHOOK END -->
        <!-- JS START -->
        <div class="col-12">
            <div class="card m-2">
                <div class="card-body">
                    <!-- /.details -->
                    <div class="col-12 card">
                        <div class="card-title">
                            <div class="h4">JS</div>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="{{ route('admin.wheelify.store') }}" name="call_js" class="d-flex">
                                @csrf
                                <input type="text" id="url" name="url_js" class="form-control"
                                    placeholder="Enter Your Store URL" />
                                <button type="submit" class="btn btn-primary">Check</button>
                            </form>
                            @if(!is_null($installed_script) && count($installed_script) > 0 )
                            <div class="list-group">
                                <div class="h6 text-center m-3 text-success">Installed JS is:</div>
                                <form method="POST" action="{{ route('admin.wheelify.store') }}" name="delete_js">
                                    @csrf
                                    <input class="form-control text-center" type="text" name="js_store"
                                        value="{{ $results_details}}" readonly>
                                    @foreach($installed_script as $js)
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="{{ $js['id'] }}"
                                                id="flexCheckDefault" name="js[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                {{ $js['src'] }}
                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#198754"
                                            class="bi bi-check-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z" />
                                        </svg>
                                    </div>
                                    @endforeach
                                    <button type="submit" class="btn btn-danger float-right m-1 show_confirm">Delete</button>
                                </form>
                                @endif
                                @if(!is_null($uninstalled_script) && count($uninstalled_script) > 0)
                                <div class="h6 text-center m-3 text-success">Uninstalled JS is:</div>
                                <form method="POST" action="{{ route('admin.wheelify.store') }}" name="install_js"
                                    class="m-4">
                                    @csrf
                                    <input class="form-control text-center my-1" type="text" name="js_store"
                                        value="{{ $results_details }}" readonly>
                                    @foreach($uninstalled_script as $item_uninstall)
                                    <div class="list-group-item d-flex justify-content-between">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"
                                                value="{{ $item_uninstall }}" id="flexCheckDefault" name="script[]">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                {{ $item_uninstall }}
                                            </label>
                                        </div>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#C82333"
                                            class="bi bi-x-circle" viewBox="0 0 16 16">
                                            <path
                                                d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            <path
                                                d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z" />
                                        </svg>
                                    </div>
                                    @endforeach
                                    <div class="h3 p-1 text-center">OR</div>
                                    <input type="text" id="url" name="script[]" class="form-control my-1"
                                        placeholder="Enter Script to be install:" />
                                    <button type="submit" class="btn btn-success m-1 float-right">Install</button>
                                </form>
                            </div>
                            @endif
                        </div>
                    </div>
                    <!-- /.details -->
                </div>
            </div>
        </div>
        <!-- JS END -->
    </div>
</div>
@endsection


@section('scripts')
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable').length) {
    $('#dataTable').DataTable({});
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script type="text/javascript">
$('.show_confirm').click(function(event) {
    var form = $(this).closest("form");
    var name = $(this).data("name");
    event.preventDefault();
    swal({
            title: `Are you sure you want to delete?`,
            text: "Deleting will never be shown again.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willDelete) => {
            if (willDelete) {
                form.submit();
            }
        });
});
</script>
@endsection