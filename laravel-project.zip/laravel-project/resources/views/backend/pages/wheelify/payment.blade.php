@extends('backend.layouts.master')

@section('title')
Salespop-Dashboard
@endsection

@section('styles')
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Wheelify</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>Payment Details</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">


    <div class="row">
        <!-- Payment START -->
        <div class="col-12 mt-5">
            <div class="card m-2">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6>Recurring Charge</h6>
                                </div>
                                <div class="card-body">
                                    <table id="dataTable1" class="display nowrap" style="width:100%">
                                        <?PHP $sr = 1; ?>
                                        <thead class="bg-light text-capitalize">
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Api Client id</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th width="10%">Return URL</th>
                                                <th>Billing Date</th>
                                                <th>Created At</th>
                                                <th>Updated At</th>
                                                <th>Test</th>
                                                <th>Activated Date</th>
                                                <th>Cancelled Date</th>
                                                <th>Trial Days</th>
                                                <th>Capped Amount</th>
                                                <th>Currency</th>
                                                <th>Trial End Date</th>
                                                <th>Balance Used</th>
                                                <th>Balance Remaining</th>
                                                <th>Risk Level</th>
                                                <th width="10%">Decorated Return URL</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($recurringCharges as $item)
                                            <tr>
                                                <td>{{ $sr }}</td>
                                                <td>{{ $item['id'] }}</td>
                                                <td>{{ $item['name'] }}</td>
                                                <td>{{ $item['api_client_id'] }}</td>
                                                <td>{{ $item['price'] }}</td>
                                                <td>{{ $item['status'] }}</td>
                                                <td>{{ $item['return_url'] }}</td>
                                                <td>{{ $item['billing_on'] }}</td>
                                                <td>{{ $item['created_at'] }}</td>
                                                <td>{{ $item['updated_at'] }}</td>
                                                <td>{{ $item['test'] }}</td>
                                                <td>{{ $item['activated_on'] }}</td>
                                                <td>{{ $item['cancelled_on'] }}</td>
                                                <td>{{ $item['trial_days'] }}</td>
                                                <td>{{ $item['capped_amount'] }}</td>
                                                <td>{{ $item['currency'] }}</td>
                                                <td>{{ $item['trial_ends_on'] }}</td>
                                                <td>{{ $item['balance_used'] }}</td>
                                                <td>{{ $item['balance_remaining'] }}</td>
                                                <td>{{ $item['risk_level'] }}</td>
                                                <td>{{ $item['decorated_return_url'] }}</td>
                                            </tr>
                                            <?PHP $sr++; ?>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6>Usage Charge</h6>
                                </div>
                                <div class="card-body">
                                    <table id="dataTable2" class="display nowrap" style="width:100%">
                                        <?PHP $sr = 1; ?>
                                        <thead class="bg-light text-capitalize">
                                            <tr>
                                                <th>Sr.no</th>
                                                <th>ID</th>
                                                <th>Description</th>
                                                <th>Price</th>
                                                <th>Created At</th>
                                                <th>Currency</th>
                                                <th>Billing Date</th>
                                                <th>Balance Used</th>
                                                <th>Balance Remaining</th>
                                                <th>Risk Level</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($usageCharges as $items)
                                            @foreach($items as $item)
                                            <tr>
                                                <td>{{ $sr}}</td>
                                                <td>{{ $item['id'] }}</td>
                                                <td>{{ $item['description'] }}</td>
                                                <td>{{ $item['price'] }}</td>
                                                <td>{{ $item['created_at'] }}</td>
                                                <td>{{ $item['currency'] }}</td>
                                                <td>{{ $item['billing_on'] }}</td>
                                                <td>{{ $item['balance_used'] }}</td>
                                                <td>{{ $item['balance_remaining'] }}</td>
                                                <td>{{ $item['risk_level'] }}</td>
                                            </tr>
                                            <?PHP $sr++; ?>
                                            @endforeach
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Payment END -->
        </div>

    </div>

    @endsection
    @section('scripts')
    <!-- Start datatable js -->
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

    <script>
    /*================================
        datatable active
        ==================================*/

    $(document).ready(function() {
        $('#dataTable1').DataTable({
            scrollX: true,
            scrollY: '200px',
            paging: false,
            ordering: false,
        });
    });
    $(document).ready(function() {
        $('#dataTable2').DataTable({
            scrollX: true,
            scrollY: '200px',
            paging: false,
            ordering: false,
        });
    });
    </script>
    @endsection