@extends('backend.layouts.master')

@section('title')
White List IP - Admin Panel
@endsection

@section('styles')
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">

@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">White List IP</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>All Data</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner my-5">
    <div class="d-flex justify-content-around">
        <!-- Salespop start -->
        @foreach($results_salespop as $ip)
        <div class="m-5">
            <div class="card">
                <div class="card-header">
                    <div class="h4 float-left">Edit Salespop White Card IP</div>
                </div>
                <div class="card-body">
                    <div class="">
                        @include('backend.layouts.partials.messages')
                        <form action="{{ route('admin.ipsalespop.update',$ip->id) }}" method="POST" name="salespop_form"
                            class="">
                            @csrf
                            @method('PUT')
                            <div class="mb-3">
                                <label for="inputIP_salespop" class="form-label">IP Address</label>
                                <input type="text" class="form-control" id="inputIP_salespop" name="inputIP_salespop"
                                    value="{{ $ip->ip }}">
                            </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">Save changes</button>
                </div>
                </form>
            </div>
        </div>
        @endforeach
        <!-- Salespop end -->
        <!-- Apper start -->
        @foreach($results_apper as $ip)
        <div class="m-5">
            <div class="card">
                <div class="card-header">
                    <div class="h4 float-left">Edit Apper White Card IP</div>
                </div>
                <div class="card-body">
                    @include('backend.layouts.partials.messages')
                    <form action="{{ route('admin.ipapper.update',$ip->id) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="mb-3">
                            <label for="inputIP_apper" class="form-label">IP Address</label>
                            <input type="text" class="form-control" id="inputIP_apper" name="inputIP_apper"
                                value="{{ $ip->ip }}">
                        </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">Save changes</button>
                </div>
                </form>
            </div>
        </div>
        @endforeach
        <!-- Apper end -->
        <!-- Wheelify start -->
        @foreach($results_wheelify as $ip)
        <div class="m-5">
            <div class="card">
                <div class="card-header">
                    <div class="h4 float-left">Edit Wheelify White Card IP</div>
                </div>
                <div class="card-body">
                    <div class="">
                        @include('backend.layouts.partials.messages')
                        <form action="{{ route('admin.ipwheelify.update',$ip->id) }}" method="POST" name="wheelify_form" class="">
                            @csrf
                            @method('PUT')
                            <div class="mb-3">
                                <label for="inputIP_wheelify" class="form-label">IP Address</label>
                                <input type="text" class="form-control" id="inputIP_wheelify" name="inputIP_wheelify"
                                    value="{{ $ip->ip }}">

                            </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">Save changes</button>
                </div>
                </form>
            </div>
        </div>
        @endforeach
        <!-- Wheelify end -->
    </div>
</div>
@endsection


@section('scripts')
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable1').length) {
    $('#dataTable1').DataTable({});
}
if ($('#dataTable2').length) {
    $('#dataTable2').DataTable({});
}
if ($('#dataTable3').length) {
    $('#dataTable3').DataTable({});
}
</script>
@endsection