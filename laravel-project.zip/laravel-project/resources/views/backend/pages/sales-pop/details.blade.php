@extends('backend.layouts.master')

@section('title')
Salespop-Dashboard
@endsection

@section('styles')
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Salespop</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>Store Details</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->

<div class="main-content-inner">

    <div class="row">
        <!-- BASIC INFO START -->
        <div class="col-12 mt-5">
            <div class="card m-2">
                <div class="card-title">
                    <div class="h4 m-4">Basic Information</div>
                </div>
                <div class="card-body">
                    <!-- /.details -->
                    <div class="row m-2">
                        @foreach($results_details as $detail)
                        <div class="col-6">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <h6>STATUS</h6>
                                <span class="badge badge-info font_size">{{$status}}</span>
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush ">
                                <li class="list-group-item d-flex justify-content-between">
                                        <div class="font_size">
                                            Payment per month
                                        </div>
                                        @foreach($results_package as $package)
                                        <div class="text-muted font_size">
                                            {{ $package->price }}
                                        </div>
                                        @endforeach
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between">
                                        <div class="font_size">
                                            Uninstalled At
                                        </div>
                                        @if($detail->app_uninstall_date != NULL)
                                        <div class="text-muted font_size">
                                            {{ $detail->app_uninstall_date }}
                                        </div>
                                        @endif
                                    </li>
                                </ul>
                            </div>
                        </div>
                        </div>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <div class="h6">PAYMENT DETAILS</div>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        @foreach($results_package as $package)
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Package</div>
                                            <div class="text-muted font_size">{{ $package->title }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Package Details</div>
                                            <div class="text-muted font_size">{{ $package->package_detail }}</div>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.details -->
                </div>
            </div>
            <div class="card m-2">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6>DETAILS</h6>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Name</div>
                                            <div class="text-muted font_size">{{ $detail->store_name }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shopify Display Name</div>
                                            <div class="text-muted font_size">{{ $detail->shopify_plan_display_name }}
                                            </div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shopify Plan Name</div>
                                            <div class="text-muted font_size">{{ $detail->shopify_plan_name }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shope Owner</div>
                                            <div class="text-muted font_size">{{ $detail->shop_owner }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Email</div>
                                            <div class="text-muted font_size">{{ $detail->email }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">URL</div>
                                            <div class="text-muted font_size">{{ $detail->url }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Domain</div>
                                            <div class="text-muted font_size">{{ $detail->domain }}</div>
                                        </li>
                                        <!-- <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">UI</div>
                                            @if($detail->show_ui_switch == 1)
                                            <div class="text-muted font_size">
                                                New UI
                                            </div>
                                            @else
                                            <div class="text-muted font_size">
                                                Old UI
                                            </div>
                                            @endif

                                        </li> -->
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">TimeZone</div>
                                            <div class="text-muted font_size">{{ $detail->timezone }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Currency</div>
                                            <div class="text-muted font_size">{{ $detail->currency }}</div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6>MODULES</h6>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Sales Notification
                                            </div>
                                            @if($detail->status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($detail->status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @foreach($results_timer as $timer)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Countdown Timer
                                            </div>
                                            @if($timer->timer_status == 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($timer->timer_status == 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_stock as $stock)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Stock Countdown
                                            </div>
                                            @if($stock->stock_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($stock->stock_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_visitor as $visitor)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Visitor Counter
                                            </div>
                                            @if($visitor->visitor_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($visitor->visitor_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_sold as $sold)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Sold Counter
                                            </div>
                                            @if($sold->sold_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($sold->sold_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_quick as $quick)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Quick View
                                            </div>
                                            @if($quick->quick_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($quick->quick_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_trust as $trust)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Trust Badges
                                            </div>
                                            @if($trust->trust_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($trust->trust_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_annoucment as $annoucment)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Annoucment Bar
                                            </div>
                                            @if($annoucment->annoucement_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($annoucment->annoucement_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_sharecart as $sharecart)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Share Cart
                                            </div>
                                            @if($sharecart->sharecart_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($sharecart->sharecart_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                        @foreach($results_stickycart as $stickycart)
                                        <li class="list-group-item d-flex justify-content-between">
                                            <div class="font_size">
                                                Sticky Cart
                                            </div>
                                            @if($stickycart->stickycart_status === 1)
                                            <span class="badge badge-success font_size">Active</span>
                                            @elseif($stickycart->stickycart_status === 0)
                                            <span class="badge badge-danger font_size">Inactive</span>
                                            @else
                                            <span class="badge badge-primary font_size">NULL</span>
                                            @endif
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- BASIC INFO END -->
            <!-- DETAIL INFO START -->

            <div class="card m-2">
                <div class="card-title">
                    <div class="h4 m-4">Details Information</div>
                </div>
                <div class="card-body">
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-6">
                            <div class="card">
                                <div class="card-header">
                                    <div class="h6">REVENUE DETAILS</div>
                                </div>
                                <div class="card-body">
                                    @foreach($results_revenue as $revenue)
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Click History</div>
                                            <div class="text-muted font_size">{{ $revenue->clicks }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Total Revenue</div>
                                            <div class="text-muted font_size">{{ $revenue->revenue }}
                                                <span class="small">{{ $detail->currency }}</span>
                                            </div>
                                        </li>
                                        @foreach($results_revenue30days as $revenue30days)
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Last 30 Days Revenue</div>
                                            <div class="text-muted font_size">{{ $revenue30days->revenue30days }}
                                            <span class="small">{{ $detail->currency }}</span>
                                            </div>
                                        </li>
                                        @endforeach
                                    </ul>
                                    @endforeach
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
            </div>
        </div>
        <!-- DETAIL INFO END -->
    </div>

</div>
@endsection


@section('scripts')
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable').length) {
    $('#dataTable').DataTable({});
}
</script>
@endsection