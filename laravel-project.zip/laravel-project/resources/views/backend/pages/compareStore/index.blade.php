@extends('backend.layouts.master')

@section('title')
CompareStores-Dashboard
@endsection

@section('styles')
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
@endsection


@section('admin-content')
<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Compare Stores</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>Compare..</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-header text-center h3">Compare Stores</div>
                <div class="card-body">
                    <div class="data-tables">
                        @include('backend.layouts.partials.messages')
                        <form method="POST" action="{{ route('admin.comparestore.store') }}" class="row m-2">
                            @csrf
                            <select class="form-control col-2 m-1" aria-label="app" name="app">
                                <option value="mysql3">AppER</option>
                                <option value="mysql2">Salespop</option>
                                <option value="mysql4">Wheelify</option>
                            </select>
                            <input class="form-control col-4 m-1" type="text" placeholder="Enter Store URL 1"
                                aria-label="storeURL" name="store1">
                            <input class="form-control col-4 m-1" type="text" placeholder="Enter Store URL 2"
                                aria-label="storeURL" name="store2">
                            <button type="submit" class="col-1 btn btn-primary m-1">Compare</button>
                        </form>
                        <div class="row">
                            <div class="col-6">
                                @if(!is_null($results_details1) && count($results_details1) > 0 )
                                <div class="h4 text-center">STORE 1</div>
                                <button class="accordion">Basic Details</button>
                                <div class="accordion-content">
                                    @foreach($results_details1['basic'] as $detail)
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Name</div>
                                            <div class="text-muted font_size">{{ $detail->store_name }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Email</div>
                                            <div class="text-muted font_size">{{ $detail->email }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shop Owner</div>
                                            <div class="text-muted font_size">{{ $detail->shop_owner }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shopify Plan</div>
                                            <div class="text-muted font_size">{{ $detail->shopify_plan_name }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Currency</div>
                                            <div class="text-muted font_size">
                                                {{ $detail->currency }}
                                            </div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Uninstall Date</div>
                                            <div class="text-muted font_size">
                                                {{ $detail->app_uninstall_date }}
                                            </div>
                                        </li>
                                    </ul>
                                    @endforeach
                                </div>
                                <button class="accordion">Modules</button>
                                @if($salespop == TRUE)
                                <div class="accordion-content">
                                    <ul class="list-group list-group-flush p-2">
                                        <button class="accordion">Quick View</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_quick'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop Position</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_position }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile Position</div>
                                                    <div class="text-muted font_size">{{ $detail->show_on_mobile }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button Text</div>
                                                    <div class="text-muted font_size">{{ $detail->button_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on Collections</div>
                                                    @if($detail->show_on_collection == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_on_collection == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on Notifications</div>
                                                    @if($detail->show_on_notification == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_on_notification == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">ATC Button color</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->atc_btn_background_color }}
                                                    </div>
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Share Cart</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_sharecart'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy Link icon BG</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->copy_link_icon_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy Link icon</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->copy_link_icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail icon BG</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mail_icon_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail icon</div>
                                                    <div class="text-muted font_size">{{ $detail->mail_icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Color</div>
                                                    <div class="text-muted font_size">{{ $detail->text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->mobile_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Share Care Message</div>
                                                    <div class="text-muted font_size">{{ $detail->sharecare_message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy icon text</div>
                                                    <div class="text-muted font_size">{{ $detail->copy_icon_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail icon text</div>
                                                    <div class="text-muted font_size">{{ $detail->mail_icon_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">After Copy text</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->after_copy_link_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy Link Flag</div>
                                                    @if($detail->copy_link_flag == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->copy_link_flag == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail Flag</div>
                                                    @if($detail->mail_flag == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->mail_flag == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Sold Counter</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_sold'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Size</div>
                                                    <div class="text-muted font_size">{{ $detail->font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Weight</div>
                                                    <div class="text-muted font_size">{{ $detail->font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Color</div>
                                                    <div class="text-muted font_size">{{ $detail->font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Align</div>
                                                    <div class="text-muted font_size">{{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Conter</div>
                                                    <div class="text-muted font_size">{{ $detail->counter }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Background color</div>
                                                    <div class="text-muted font_size">{{ $detail->background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon color</div>
                                                    <div class="text-muted font_size">{{ $detail->icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Counter color</div>
                                                    <div class="text-muted font_size">{{ $detail->count_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon</div>
                                                    <div class="text-muted font_size">{{ $detail->icon }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Theme ID</div>
                                                    @if($detail->theme_id == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->theme_id == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Variant Option</div>
                                                    @if($detail->variant_option == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->variant_option == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Sticky Cart</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_stickycart'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart icon color</div>
                                                    <div class="text-muted font_size">{{ $detail->cart_icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart icon BG</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->cart_icon_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer text color</div>
                                                    <div class="text-muted font_size">{{ $detail->drawer_text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer Bg</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->drawer_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer button color</div>
                                                    <div class="text-muted font_size">{{ $detail->drawer_button_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer button text color</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->drawer_button_text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer button font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->drawer_button_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart heading font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->cart_heading_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">All font size</div>
                                                    <div class="text-muted font_size">{{ $detail->total_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon tagline</div>
                                                    <div class="text-muted font_size">{{ $detail->icon_tag_line }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Total text</div>
                                                    <div class="text-muted font_size">{{ $detail->total_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on mobile</div>
                                                    @if($detail->show_on_mobile == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_on_mobile == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop position</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_placement }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile position</div>
                                                    <div class="text-muted font_size">{{ $detail->mobile_placement }}
                                                    </div>
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Stock Countdown</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_stock'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Size</div>
                                                    <div class="text-muted font_size">{{ $detail->font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Weight</div>
                                                    <div class="text-muted font_size">{{ $detail->font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Color</div>
                                                    <div class="text-muted font_size">{{ $detail->font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Align</div>
                                                    <div class="text-muted font_size">{{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Foreground Color</div>
                                                    <div class="text-muted font_size">{{ $detail->forground_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Background color</div>
                                                    <div class="text-muted font_size">{{ $detail->background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Restriction</div>
                                                    <div class="text-muted font_size">{{ $detail->do_restrict }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Manual Percentage</div>
                                                    @if($detail->manual_percent_check == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->manual_percent_check == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Percentage</div>
                                                    <div class="text-muted font_size">{{ $detail->percentage }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Variant</div>
                                                    @if($detail->variant_check == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->variant_check == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Stock color</div>
                                                    <div class="text-muted font_size">{{ $detail->stock_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Sold message settings</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->sold_message_settings }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Stock Restriction setting</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->stock_restriction_settings }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Stockbar animations</div>
                                                    @if($detail->stock_bar_animation == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->stock_bar_animation == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Countdown Timer</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_timer'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Title Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->title_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Title Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->title_font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Title Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->title_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Numbers Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->numbers_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Numbers Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->numbers_font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Numbers Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->numbers_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Labels Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->labels_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Labels Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->labels_font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Labels Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->labels_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Align</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Days Label</div>
                                                    <div class="text-muted font_size">{{ $detail->days_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Hours Label</div>
                                                    <div class="text-muted font_size">{{ $detail->hours_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Minutes Label</div>
                                                    <div class="text-muted font_size">{{ $detail->minutes_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Seconds Label</div>
                                                    <div class="text-muted font_size">{{ $detail->seconds_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">DateTime</div>
                                                    <div class="text-muted font_size">{{ $detail->datetimes }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Start Date</div>
                                                    <div class="text-muted font_size">{{ $detail->start_date_time }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">End Date</div>
                                                    <div class="text-muted font_size">{{ $detail->end_date_time }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Days</div>
                                                    @if($detail->days_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->days_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Hours</div>
                                                    @if($detail->hours_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->hours_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Minutes</div>
                                                    @if($detail->minutes_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->minutes_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Seconds</div>
                                                    @if($detail->seconds_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->seconds_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Repeat Conter</div>
                                                    @if($detail->repeat_count_end == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->repeat_count_end == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on collection page</div>
                                                    @if($detail->show_timer_on_collections_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_timer_on_collections_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Trust Badges</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_trust'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font family</div>
                                                    <div class="text-muted font_size">{{ $detail->header_font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->header_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font color</div>
                                                    <div class="text-muted font_size">{{ $detail->header_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header text alignment</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->header_text_alignment }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font color</div>
                                                    <div class="text-muted font_size">{{ $detail->header_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Badge size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->badges_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Badge color</div>
                                                    <div class="text-muted font_size">{{ $detail->badges_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header text</div>
                                                    <div class="text-muted font_size">{{ $detail->header_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Badges alignment</div>
                                                    <div class="text-muted font_size">{{ $detail->badges_alignment }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Template code</div>
                                                    <div class="text-muted font_size">{{ $detail->template_code }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Margin</div>
                                                    @if($detail->custom_margin_show_hide == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->custom_margin_show_hide == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Margin Top</div>
                                                    @if($detail->custom_margin_top == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->custom_margin_top == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Margin bottom</div>
                                                    @if($detail->custom_margin_bottom == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->custom_margin_bottom == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Product page</div>
                                                    @if($detail->product_page_show_hide == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->product_page_show_hide == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Visitor Counter</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_visitor'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text align</div>
                                                    <div class="text-muted font_size">{{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Visitors</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->visitors }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">counter</div>
                                                    <div class="text-muted font_size">{{ $detail->counter }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Background color</div>
                                                    <div class="text-muted font_size">{{ $detail->background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon color</div>
                                                    <div class="text-muted font_size">{{ $detail->icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Count color</div>
                                                    <div class="text-muted font_size">{{ $detail->count_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon</div>
                                                    <div class="text-muted font_size">{{ $detail->icon }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Duration</div>
                                                    <div class="text-muted font_size">{{ $detail->duration }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Counter</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->custom_visitor_counter }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Annoucment Bar</button>
                                        <div class="accordion-content">
                                            @foreach($results_details1['module_annoucement'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar font family</div>
                                                    <div class="text-muted font_size">{{ $detail->bar_font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar bg font color</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->bar_background_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar font color</div>
                                                    <div class="text-muted font_size">{{ $detail->bar_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Coupon code color</div>
                                                    <div class="text-muted font_size">{{ $detail->coupon_code_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar desktop font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->bar_desktop_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar mobile font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->bar_mobile_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar text</div>
                                                    <div class="text-muted font_size">{{ $detail->bar_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Link on click</div>
                                                    <div class="text-muted font_size">{{ $detail->on_click_go_to }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button text</div>
                                                    <div class="text-muted font_size">{{ $detail->button_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button color</div>
                                                    <div class="text-muted font_size">{{ $detail->button_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button text color</div>
                                                    <div class="text-muted font_size">{{ $detail->button_text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Discount code text</div>
                                                    <div class="text-muted font_size">{{ $detail->discount_code_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop position</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_placement }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop padding</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->desktop_custom_padding }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop margin top</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->desktop_custom_margin_top }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop margin bottom</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->desktop_custom_margin_bottom }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile position</div>
                                                    <div class="text-muted font_size">{{ $detail->mobile_placement }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile padding</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mobile_custom_padding }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile margin top</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mobile_custom_margin_top }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile margin bottom</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mobile_custom_margin_bottom }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">New tab</div>
                                                    @if($detail->new_tab == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->new_tab == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show button</div>
                                                    @if($detail->show_button == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_button == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button shape</div>
                                                    @if($detail->button_shape == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->button_shape == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Discount code</div>
                                                    @if($detail->show_discount_code == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_discount_code == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar position</div>
                                                    @if($detail->bar_position == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->bar_position == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar show on</div>
                                                    @if($detail->bar_show_on == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->bar_show_on == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Pages type</div>
                                                    @if($detail->pages_type == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->pages_type == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Home page</div>
                                                    @if($detail->home_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->home_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Product page</div>
                                                    @if($detail->product_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->product_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Collection page</div>
                                                    @if($detail->collection_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->collection_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart page</div>
                                                    @if($detail->cart_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->cart_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Hide close button</div>
                                                    @if($detail->hide_close_button == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->hide_close_button == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Start Date</div>
                                                    <div class="text-muted font_size">{{ $detail->start_date }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Set start time</div>
                                                    @if($detail->set_start_time == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->set_start_time == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">End Date</div>
                                                    <div class="text-muted font_size">{{ $detail->end_date }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Set End time</div>
                                                    @if($detail->set_end_time == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->set_end_time == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar placement</div>
                                                    @if($detail->bar_placement == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->bar_placement == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Theme Id</div>
                                                    @if($detail->theme_id == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->theme_id == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Module settings</div>
                                                    <div class="text-muted font_size">{{ $detail->modules_settings }}
                                                    </div>
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                    </ul>
                                </div>
                                @endif
                                @if($apper == TRUE)
                                <div class="accordion-content">
                                    <ul class="list-group list-group-flush p-2">
                                        @foreach($results_details1['module'] as $detail)
                                        <button class="accordion">{{ $detail->title }}</button>
                                        <div class="accordion-content m-1">
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Status</div>
                                                @if($detail->is_active == 1)
                                                <span class="badge badge-success font_size">Active</span>
                                                @elseif($detail->is_active == 0)
                                                <span class="badge badge-danger font_size">Inactive</span>
                                                @else
                                                <span class="badge badge-primary font_size">NULL</span>
                                                @endif
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Email Campaign</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->email_campaign }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Shop name</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->shop_name }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">From Emal</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->from_email }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail banner</div>
                                                <div class="text-muted font_size">{{ $detail->email_banner }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after hours</div>
                                                <div class="text-muted font_size">{{ $detail->email_send_after_hours }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after days</div>
                                                <div class="text-muted font_size">{{ $detail->email_send_after_days }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after minutes</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->email_send_after_minutes }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after minutes actual</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->email_send_after_minutes_actual }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Call to action text</div>
                                                <div class="text-muted font_size">{{ $detail->call_to_action_text }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Call to action text color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->call_to_action_text_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Call to action button color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->call_to_action_button_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Footer email</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->footer_email }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Subject</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->subject }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spam score</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spam_score }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Body</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->body }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Created Date</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->created_at }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Subject</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->subject }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Updated Date</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->updated_at }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Tested</div>
                                                @if($detail->is_test == 1)
                                                <span class="text-muted font_size">True</span>
                                                @elseif($detail->is_test == 0)
                                                <span class="text-muted font_size">False</span>
                                                @else
                                                <span class="text-muted font_size">NULL</span>
                                                @endif
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Time type</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->time_type }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Time value</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->time_value }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">App type</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->app_type }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Theme</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->et_theme }}
                                                </div>
                                            </li>
                                            <button class="accordion">Description</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->description }}
                                                </span>
                                            </div>
                                            <button class="accordion">Body Pro</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->body_pro }}
                                                </span>
                                            </div>
                                        </div>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                                @if($wheelify == TRUE)
                                <div class="accordion-content">
                                    <ul class="list-group list-group-flush p-2">
                                        @foreach($results_details1['module'] as $detail)
                                        <button class="accordion"> {{ $detail->spinner_theme }}</button>
                                        <div class="accordion-content m-1">
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Status</div>
                                                @if($detail->is_active == 1)
                                                <span class="badge badge-success font_size">Active</span>
                                                @elseif($detail->is_active == 0)
                                                <span class="badge badge-danger font_size">Inactive</span>
                                                @else
                                                <span class="badge badge-primary font_size">NULL</span>
                                                @endif
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner Theme</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_theme }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG url</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_background_image_url }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG url mobile</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_background_image_url_mobile }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner close color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_close_cross_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG color</div>
                                                <div class="text-muted font_size">{{ $detail->spinner_bg_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG image</div>
                                                <div class="text-muted font_size">{{ $detail->spinner_bg_image }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG image mobile</div>
                                                <div class="text-muted font_size">{{ $detail->spinner_bg_mobile_image }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner peg image</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_peg_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Try luck BG color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->try_luck_bg_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Try luck text color</div>
                                                <div class="text-muted font_size">{{ $detail->try_luck_text_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Wheel stroke color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->wheel_stroke_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">center circle stroke color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->center_circle_stroke_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Center circle fill color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->center_circle_fill_color }}
                                                </div>
                                            </li>
                                            <button class="accordion">Settings</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->settings_data }}
                                                </span>
                                            </div>
                                            <button class="accordion">Conversion Settings</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->conversion_booster_settings_data }}
                                                </span>
                                            </div>
                                            <button class="accordion">Anti Cheat Engine Settings</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->anti_cheat_engine_settings_data }}
                                                </span>
                                            </div>
                                        </div>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                                @endif
                            </div>
                            <div class="col-6">
                                @if(!is_null($results_details2) && count($results_details2) > 0 )
                                <div class="h4 text-center">STORE 2</div>
                                <button class="accordion">Basic Details</button>
                                <div class="accordion-content">
                                    @foreach($results_details2['basic'] as $detail)
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Name</div>
                                            <div class="text-muted font_size">{{ $detail->store_name }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Email</div>
                                            <div class="text-muted font_size">{{ $detail->email }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shop Owner</div>
                                            <div class="text-muted font_size">{{ $detail->shop_owner }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Shopify Plan</div>
                                            <div class="text-muted font_size">{{ $detail->shopify_plan_name }}</div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Store Currency</div>
                                            <div class="text-muted font_size">
                                                {{ $detail->currency }}
                                            </div>
                                        </li>
                                        <li class="list-group-item  d-flex justify-content-between">
                                            <div class="font_size">Uninstall Date</div>
                                            <div class="text-muted font_size">
                                                {{ $detail->app_uninstall_date }}
                                            </div>
                                        </li>
                                    </ul>
                                    @endforeach
                                </div>
                                <button class="accordion">Modules</button>
                                @if($salespop == TRUE)
                                <div class="accordion-content">
                                    <ul class="list-group list-group-flush p-2">
                                        <button class="accordion">Quick View</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_quick'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop Position</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_position }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile Position</div>
                                                    <div class="text-muted font_size">{{ $detail->show_on_mobile }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button Text</div>
                                                    <div class="text-muted font_size">{{ $detail->button_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on Collections</div>
                                                    @if($detail->show_on_collection == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_on_collection == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on Notifications</div>
                                                    @if($detail->show_on_notification == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_on_notification == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">ATC Button color</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->atc_btn_background_color }}
                                                    </div>
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Share Cart</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_sharecart'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy Link icon BG</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->copy_link_icon_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy Link icon</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->copy_link_icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail icon BG</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mail_icon_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail icon</div>
                                                    <div class="text-muted font_size">{{ $detail->mail_icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Color</div>
                                                    <div class="text-muted font_size">{{ $detail->text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->mobile_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Share Care Message</div>
                                                    <div class="text-muted font_size">{{ $detail->sharecare_message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy icon text</div>
                                                    <div class="text-muted font_size">{{ $detail->copy_icon_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail icon text</div>
                                                    <div class="text-muted font_size">{{ $detail->mail_icon_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">After Copy text</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->after_copy_link_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Copy Link Flag</div>
                                                    @if($detail->copy_link_flag == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->copy_link_flag == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mail Flag</div>
                                                    @if($detail->mail_flag == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->mail_flag == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Sold Counter</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_sold'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Size</div>
                                                    <div class="text-muted font_size">{{ $detail->font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Weight</div>
                                                    <div class="text-muted font_size">{{ $detail->font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Color</div>
                                                    <div class="text-muted font_size">{{ $detail->font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Align</div>
                                                    <div class="text-muted font_size">{{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Conter</div>
                                                    <div class="text-muted font_size">{{ $detail->counter }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Background color</div>
                                                    <div class="text-muted font_size">{{ $detail->background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon color</div>
                                                    <div class="text-muted font_size">{{ $detail->icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Counter color</div>
                                                    <div class="text-muted font_size">{{ $detail->count_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon</div>
                                                    <div class="text-muted font_size">{{ $detail->icon }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Theme ID</div>
                                                    @if($detail->theme_id == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->theme_id == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Variant Option</div>
                                                    @if($detail->variant_option == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->variant_option == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Sticky Cart</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_stickycart'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart icon color</div>
                                                    <div class="text-muted font_size">{{ $detail->cart_icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart icon BG</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->cart_icon_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer text color</div>
                                                    <div class="text-muted font_size">{{ $detail->drawer_text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer Bg</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->drawer_background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer button color</div>
                                                    <div class="text-muted font_size">{{ $detail->drawer_button_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer button text color</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->drawer_button_text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Drawer button font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->drawer_button_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart heading font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->cart_heading_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">All font size</div>
                                                    <div class="text-muted font_size">{{ $detail->total_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon tagline</div>
                                                    <div class="text-muted font_size">{{ $detail->icon_tag_line }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Total text</div>
                                                    <div class="text-muted font_size">{{ $detail->total_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on mobile</div>
                                                    @if($detail->show_on_mobile == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_on_mobile == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop position</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_placement }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile position</div>
                                                    <div class="text-muted font_size">{{ $detail->mobile_placement }}
                                                    </div>
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Stock Countdown</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_stock'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Size</div>
                                                    <div class="text-muted font_size">{{ $detail->font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Weight</div>
                                                    <div class="text-muted font_size">{{ $detail->font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Color</div>
                                                    <div class="text-muted font_size">{{ $detail->font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Align</div>
                                                    <div class="text-muted font_size">{{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Foreground Color</div>
                                                    <div class="text-muted font_size">{{ $detail->forground_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Background color</div>
                                                    <div class="text-muted font_size">{{ $detail->background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Restriction</div>
                                                    <div class="text-muted font_size">{{ $detail->do_restrict }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Manual Percentage</div>
                                                    @if($detail->manual_percent_check == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->manual_percent_check == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Percentage</div>
                                                    <div class="text-muted font_size">{{ $detail->percentage }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Variant</div>
                                                    @if($detail->variant_check == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->variant_check == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Stock color</div>
                                                    <div class="text-muted font_size">{{ $detail->stock_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Sold message settings</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->sold_message_settings }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Stock Restriction setting</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->stock_restriction_settings }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Stockbar animations</div>
                                                    @if($detail->stock_bar_animation == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->stock_bar_animation == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Countdown Timer</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_timer'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font Family</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Title Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->title_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Title Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->title_font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Title Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->title_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Numbers Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->numbers_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Numbers Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->numbers_font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Numbers Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->numbers_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Labels Font size</div>
                                                    <div class="text-muted font_size">{{ $detail->labels_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Labels Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->labels_font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Labels Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->labels_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text Align</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Days Label</div>
                                                    <div class="text-muted font_size">{{ $detail->days_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Hours Label</div>
                                                    <div class="text-muted font_size">{{ $detail->hours_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Minutes Label</div>
                                                    <div class="text-muted font_size">{{ $detail->minutes_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Seconds Label</div>
                                                    <div class="text-muted font_size">{{ $detail->seconds_label }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">DateTime</div>
                                                    <div class="text-muted font_size">{{ $detail->datetimes }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Start Date</div>
                                                    <div class="text-muted font_size">{{ $detail->start_date_time }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">End Date</div>
                                                    <div class="text-muted font_size">{{ $detail->end_date_time }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Days</div>
                                                    @if($detail->days_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->days_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Hours</div>
                                                    @if($detail->hours_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->hours_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Minutes</div>
                                                    @if($detail->minutes_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->minutes_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Seconds</div>
                                                    @if($detail->seconds_on_off == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->seconds_on_off == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Repeat Conter</div>
                                                    @if($detail->repeat_count_end == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->repeat_count_end == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show on collection page</div>
                                                    @if($detail->show_timer_on_collections_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_timer_on_collections_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Trust Badges</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_trust'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font family</div>
                                                    <div class="text-muted font_size">{{ $detail->header_font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->header_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font color</div>
                                                    <div class="text-muted font_size">{{ $detail->header_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header text alignment</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->header_text_alignment }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header font color</div>
                                                    <div class="text-muted font_size">{{ $detail->header_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Badge size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->badges_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Badge color</div>
                                                    <div class="text-muted font_size">{{ $detail->badges_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Header text</div>
                                                    <div class="text-muted font_size">{{ $detail->header_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Badges alignment</div>
                                                    <div class="text-muted font_size">{{ $detail->badges_alignment }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Template code</div>
                                                    <div class="text-muted font_size">{{ $detail->template_code }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Margin</div>
                                                    @if($detail->custom_margin_show_hide == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->custom_margin_show_hide == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Margin Top</div>
                                                    @if($detail->custom_margin_top == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->custom_margin_top == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Margin bottom</div>
                                                    @if($detail->custom_margin_bottom == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->custom_margin_bottom == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Product page</div>
                                                    @if($detail->product_page_show_hide == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->product_page_show_hide == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Visitor Counter</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_visitor'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font family</div>
                                                    <div class="text-muted font_size">{{ $detail->font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font weight</div>
                                                    <div class="text-muted font_size">{{ $detail->font_weight }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Font color</div>
                                                    <div class="text-muted font_size">{{ $detail->font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Text align</div>
                                                    <div class="text-muted font_size">{{ $detail->text_align }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Visitors</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->visitors }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">counter</div>
                                                    <div class="text-muted font_size">{{ $detail->counter }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Background color</div>
                                                    <div class="text-muted font_size">{{ $detail->background_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon color</div>
                                                    <div class="text-muted font_size">{{ $detail->icon_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Count color</div>
                                                    <div class="text-muted font_size">{{ $detail->count_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Message</div>
                                                    <div class="text-muted font_size">{{ $detail->message }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Icon</div>
                                                    <div class="text-muted font_size">{{ $detail->icon }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Duration</div>
                                                    <div class="text-muted font_size">{{ $detail->duration }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Custom Counter</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->custom_visitor_counter }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Above ATC</div>
                                                    @if($detail->above_cart == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->above_cart == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                        <button class="accordion">Annoucment Bar</button>
                                        <div class="accordion-content">
                                            @foreach($results_details2['module_annoucement'] as $detail)
                                            <ul class="list-group list-group-flush">
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Status</div>
                                                    @if($detail->on_off == 1)
                                                    <span class="badge badge-success font_size">Active</span>
                                                    @elseif($detail->on_off == 0)
                                                    <span class="badge badge-danger font_size">Inactive</span>
                                                    @else
                                                    <span class="badge badge-primary font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar font family</div>
                                                    <div class="text-muted font_size">{{ $detail->bar_font_family }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar bg font color</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->bar_background_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar font color</div>
                                                    <div class="text-muted font_size">{{ $detail->bar_font_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Coupon code color</div>
                                                    <div class="text-muted font_size">{{ $detail->coupon_code_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar desktop font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->bar_desktop_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar mobile font size</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->bar_mobile_font_size }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar text</div>
                                                    <div class="text-muted font_size">{{ $detail->bar_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Link on click</div>
                                                    <div class="text-muted font_size">{{ $detail->on_click_go_to }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button text</div>
                                                    <div class="text-muted font_size">{{ $detail->button_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button color</div>
                                                    <div class="text-muted font_size">{{ $detail->button_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button text color</div>
                                                    <div class="text-muted font_size">{{ $detail->button_text_color }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Discount code text</div>
                                                    <div class="text-muted font_size">{{ $detail->discount_code_text }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop position</div>
                                                    <div class="text-muted font_size">{{ $detail->desktop_placement }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop padding</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->desktop_custom_padding }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop margin top</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->desktop_custom_margin_top }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Desktop margin bottom</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->desktop_custom_margin_bottom }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile position</div>
                                                    <div class="text-muted font_size">{{ $detail->mobile_placement }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile padding</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mobile_custom_padding }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile margin top</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mobile_custom_margin_top }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Mobile margin bottom</div>
                                                    <div class="text-muted font_size">
                                                        {{ $detail->mobile_custom_margin_bottom }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">New tab</div>
                                                    @if($detail->new_tab == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->new_tab == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Show button</div>
                                                    @if($detail->show_button == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_button == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Button shape</div>
                                                    @if($detail->button_shape == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->button_shape == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Discount code</div>
                                                    @if($detail->show_discount_code == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->show_discount_code == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar position</div>
                                                    @if($detail->bar_position == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->bar_position == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar show on</div>
                                                    @if($detail->bar_show_on == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->bar_show_on == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Pages type</div>
                                                    @if($detail->pages_type == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->pages_type == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Home page</div>
                                                    @if($detail->home_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->home_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Product page</div>
                                                    @if($detail->product_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->product_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Collection page</div>
                                                    @if($detail->collection_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->collection_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Cart page</div>
                                                    @if($detail->cart_page == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->cart_page == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Hide close button</div>
                                                    @if($detail->hide_close_button == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->hide_close_button == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Start Date</div>
                                                    <div class="text-muted font_size">{{ $detail->start_date }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Set start time</div>
                                                    @if($detail->set_start_time == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->set_start_time == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">End Date</div>
                                                    <div class="text-muted font_size">{{ $detail->end_date }}
                                                    </div>
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Set End time</div>
                                                    @if($detail->set_end_time == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->set_end_time == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Bar placement</div>
                                                    @if($detail->bar_placement == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->bar_placement == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Theme Id</div>
                                                    @if($detail->theme_id == 1)
                                                    <span class="text-muted font_size">Active</span>
                                                    @elseif($detail->theme_id == 0)
                                                    <span class="text-muted font_size">Inactive</span>
                                                    @else
                                                    <span class="text-muted font_size">NULL</span>
                                                    @endif
                                                </li>
                                                <li class="list-group-item  d-flex justify-content-between">
                                                    <div class="font_size">Module settings</div>
                                                    <div class="text-muted font_size">{{ $detail->modules_settings }}
                                                    </div>
                                                </li>
                                            </ul>
                                            @endforeach
                                        </div>
                                    </ul>
                                </div>
                                @endif
                                @if($apper == TRUE)
                                <div class="accordion-content">
                                    <ul class="list-group list-group-flush p-2">
                                        @foreach($results_details2['module'] as $detail)
                                        <button class="accordion">{{ $detail->title }}</button>
                                        <div class="accordion-content m-1">
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Status</div>
                                                @if($detail->is_active == 1)
                                                <span class="badge badge-success font_size">Active</span>
                                                @elseif($detail->is_active == 0)
                                                <span class="badge badge-danger font_size">Inactive</span>
                                                @else
                                                <span class="badge badge-primary font_size">NULL</span>
                                                @endif
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Email Campaign</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->email_campaign }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Shop name</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->shop_name }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">From Emal</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->from_email }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail banner</div>
                                                <div class="text-muted font_size">{{ $detail->email_banner }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after hours</div>
                                                <div class="text-muted font_size">{{ $detail->email_send_after_hours }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after days</div>
                                                <div class="text-muted font_size">{{ $detail->email_send_after_days }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after minutes</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->email_send_after_minutes }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Mail send after minutes actual</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->email_send_after_minutes_actual }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Call to action text</div>
                                                <div class="text-muted font_size">{{ $detail->call_to_action_text }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Call to action text color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->call_to_action_text_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Call to action button color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->call_to_action_button_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Footer email</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->footer_email }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Subject</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->subject }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spam score</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spam_score }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Body</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->body }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Created Date</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->created_at }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Subject</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->subject }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Updated Date</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->updated_at }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Tested</div>
                                                @if($detail->is_test == 1)
                                                <span class="text-muted font_size">True</span>
                                                @elseif($detail->is_test == 0)
                                                <span class="text-muted font_size">False</span>
                                                @else
                                                <span class="text-muted font_size">NULL</span>
                                                @endif
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Time type</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->time_type }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Time value</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->time_value }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">App type</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->app_type }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Theme</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->et_theme }}
                                                </div>
                                            </li>
                                            <button class="accordion">Description</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->description }}
                                                </span>
                                            </div>
                                            <button class="accordion">Body Pro</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->body_pro }}
                                                </span>
                                            </div>
                                        </div>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                                @if($wheelify == TRUE)
                                <div class="accordion-content">
                                    <ul class="list-group list-group-flush p-2">
                                        @foreach($results_details2['module'] as $detail)
                                        <button class="accordion"> {{ $detail->spinner_theme }}</button>
                                        <div class="accordion-content m-1">
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Status</div>
                                                @if($detail->is_active == 1)
                                                <span class="badge badge-success font_size">Active</span>
                                                @elseif($detail->is_active == 0)
                                                <span class="badge badge-danger font_size">Inactive</span>
                                                @else
                                                <span class="badge badge-primary font_size">NULL</span>
                                                @endif
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner Theme</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_theme }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG url</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_background_image_url }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG url mobile</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_background_image_url_mobile }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner close color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_close_cross_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG color</div>
                                                <div class="text-muted font_size">{{ $detail->spinner_bg_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG image</div>
                                                <div class="text-muted font_size">{{ $detail->spinner_bg_image }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner BG image mobile</div>
                                                <div class="text-muted font_size">{{ $detail->spinner_bg_mobile_image }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Spinner peg image</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->spinner_peg_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Try luck BG color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->try_luck_bg_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Try luck text color</div>
                                                <div class="text-muted font_size">{{ $detail->try_luck_text_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Wheel stroke color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->wheel_stroke_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">center circle stroke color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->center_circle_stroke_color }}
                                                </div>
                                            </li>
                                            <li class="list-group-item  d-flex justify-content-between">
                                                <div class="font_size">Center circle fill color</div>
                                                <div class="text-muted font_size">
                                                    {{ $detail->center_circle_fill_color }}
                                                </div>
                                            </li>
                                            <button class="accordion">Settings</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->settings_data }}
                                                </span>
                                            </div>
                                            <button class="accordion">Conversion Settings</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->conversion_booster_settings_data }}
                                                </span>
                                            </div>
                                            <button class="accordion">Anti Cheat Engine Settings</button>
                                            <div class="accordion-content">
                                                <span>
                                                    {{ $detail->anti_cheat_engine_settings_data }}
                                                </span>
                                            </div>
                                        </div>
                                        @endforeach
                                    </ul>
                                </div>
                                @endif
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- data table end -->
    </div>
</div>
@endsection


@section('scripts')
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable').length) {
    $('#dataTable').DataTable({});
}
</script>
<script>
const accordionBtns = document.querySelectorAll(".accordion");
var maxContentHeight = '100%';
accordionBtns.forEach((accordion) => {
    accordion.onclick = function() {
        this.classList.toggle("is-open");

        let content = this.nextElementSibling;
        console.log(content);

        if (content.style.maxHeight) {
            //this is if the accordion is open
            content.style.maxHeight = null;
        } else {
            //if the accordion is currently closed
            content.style.maxHeight = maxContentHeight;
            console.log(content.style.maxHeight);
        }
    };
});
</script>

@endsection