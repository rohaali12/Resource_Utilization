@extends('backend.layouts.master')

@section('title')
Ghostlogin-Dashboard
@endsection

@section('styles')
<!-- Start datatable css -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.jqueryui.min.css">
<meta name="csrf-token" content="{{ csrf_token() }}">
@endsection


@section('admin-content')

<!-- page title area start -->
<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-sm-6">
            <div class="breadcrumbs-area clearfix">
                <h4 class="page-title pull-left">Ghost Login</h4>
                <ul class="breadcrumbs pull-left">
                    <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
                    <li><span>login</span></li>
                </ul>
            </div>
        </div>
        <div class="col-sm-6 clearfix">
            @include('backend.layouts.partials.logout')
        </div>
    </div>
</div>
<!-- page title area end -->
<div class="main-content-inner">
    <div class="row">
        <!-- data table start -->
        <div class="col-12 mt-5">
            <div class="card">
                <div class="card-header text-center h3">Ghost Login</div>
                <div class="card-body">
                    <div class="text-center" id="ghost-alert" style="display: none"></div>
                    @include('backend.layouts.partials.messages')
                    <form method="POST" id="g_login" class="m-2">
                        @csrf
                        @method('POST')
                        <div class="d-flex justify-content-center m-3">
                            <div class="row w-50">
                                <div class="col-12">
                                    <select class="form-control m-1" aria-label="app" name="app" id="app">
                                        <option value="mysql3">AppER</option>
                                        <option value="mysql2">Salespop</option>
                                        <option value="mysql4">Wheelify</option>
                                        <option value="mysql5">Abandoned Protector</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <input class="form-control m-1" type="text" placeholder="Enter Email"
                                        aria-label="userName" id="userName" name="userName" required>
                                </div>
                                <div class="col-12">
                                    <input class="form-control m-1" type="text" placeholder="Enter Password"
                                        aria-label="password" id="password" name="password" required>
                                </div>
                                <div class="col-12">
                                    <input class="form-control m-1" type="text" placeholder="Enter Shop URL"
                                        aria-label="shop" id="shop" name="shop" required>
                                </div>
                                <div class="col-12">
                                    <button class="form-control m-1" type="submit"
                                        class="btn btn-primary">Login</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- data table end -->

    </div>
</div>
@endsection


@section('scripts')
<!-- Start datatable js -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>

<script>
/*================================
        datatable active
        ==================================*/
if ($('#dataTable').length) {
    $('#dataTable').DataTable({});
}
</script>
<script type="text/javascript">
$.ajaxSetup({
    crossDomain: true,
    xhrFields: {
        withCredentials: true
    }
});
$("#g_login").submit(function(event) {
    event.preventDefault();
    $.ajax({
        url: "{{ route('admin.ghostlogin.store') }}",
        type: "POST",
        data: $('#g_login').serialize(),
        dataType: "json",
        success: function(data) {
            if (data && data._metadata && data._metadata.outcomeCode === 0) {
                $('#ghost-alert').attr('class', 'alert alert-success').html(data._metadata.message)
                .show();
                setTimeout(function() {
                    // Redirect to the new URL
                    window.location.replace(data.records.url);
                }, 3000);
            } else if (data && data._metadata) {
                // Handle errors or display a message
                console.log(data._metadata.message);
            }
        },
        error: function(xhr, status, error) {
            $('#ghost-alert').attr('class', 'alert alert-danger').html(data._metadata.message)
            .show();
            console.log(error);
        }
    });
    return false;
});
</script>
@endsection