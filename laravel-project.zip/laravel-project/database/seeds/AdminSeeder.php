<?php

use App\Models\Admin;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin = Admin::where('username', 'mainadmin')->first();

        if (is_null($admin)) {
            $admin           = new Admin();
            $admin->name     = "Main Admin";
            $admin->email    = "mainadmin@gmail.com";
            $admin->username = "mainadmin";
            $admin->password = Hash::make('12345678');
            $admin->save();
        }
    }
}
